## Packages
recharts | For visualizing weight trends and calorie distribution
framer-motion | For smooth page transitions and micro-interactions
date-fns | For date formatting and manipulation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Playfair Display", "serif"],
  mono: ["JetBrains Mono", "monospace"],
}
