import { Link, useLocation } from "wouter";
import { Activity, BookOpen, User, LogOut, Pill, Layers } from "lucide-react";
import { setStoredUsername, getStoredUsername } from "@/hooks/use-user";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useReminderEngine } from "@/hooks/use-reminder-engine";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const username = getStoredUsername();
  
  useReminderEngine(username || undefined);

  const handleLogout = () => {
    setStoredUsername("");
    queryClient.clear();
    window.location.href = "/";
  };

  const navItems = [
    { href: "/dashboard", icon: Activity, label: "Dashboard" },
    { href: "/supplements", icon: Pill, label: "Supplements" },
    { href: "/stacks", icon: Layers, label: "Stacks" },
    { href: "/playbook", icon: BookOpen, label: "Playbook" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 sm:px-6">
          <Link href="/dashboard" className="flex items-center gap-2 font-display text-xl font-bold tracking-tighter">
            <span className="text-accent">◆</span>
            <span>PRFMR</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === item.href ? "text-primary" : "text-muted-foreground"
                )}
              >
                {item.label}
              </Link>
            ))}
            <button
              onClick={handleLogout}
              className="text-sm font-medium text-muted-foreground hover:text-destructive transition-colors ml-4"
            >
              Log out
            </button>
          </nav>

          <div className="md:hidden">
            {/* Mobile menu trigger could go here, but focusing on bottom nav for mobile */}
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 py-8 sm:px-6 lg:py-10 max-w-5xl mx-auto">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-background p-2 pb-safe z-50 flex justify-around items-center">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors min-w-[64px]",
              location === item.href ? "text-primary bg-secondary" : "text-muted-foreground"
            )}
          >
            <item.icon className="h-5 w-5" />
            <span className="text-[10px] font-medium">{item.label}</span>
          </Link>
        ))}
        <button
          onClick={handleLogout}
          className="flex flex-col items-center gap-1 p-2 rounded-lg text-muted-foreground hover:bg-secondary/50 min-w-[64px]"
        >
          <LogOut className="h-5 w-5" />
          <span className="text-[10px] font-medium">Exit</span>
        </button>
      </nav>
      
      <div className="md:hidden h-20" /> {/* Spacer for bottom nav */}
    </div>
  );
}
