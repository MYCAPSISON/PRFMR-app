import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  target?: string | number;
  unit?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "neutral";
  className?: string;
}

export function StatCard({ title, value, target, unit, icon, trend, className }: StatCardProps) {
  const percentage = target 
    ? Math.min(Math.round((Number(value) / Number(target)) * 100), 100)
    : 0;

  return (
    <div className={cn(
      "bg-card border rounded-xl p-5 shadow-sm transition-all hover:shadow-md",
      className
    )}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        {icon && <div className="text-muted-foreground/50">{icon}</div>}
      </div>
      
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold font-mono tracking-tight">{value}</span>
        {unit && <span className="text-xs text-muted-foreground font-medium">{unit}</span>}
      </div>
      
      {target && (
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Target: {target}</span>
            <span>{percentage}%</span>
          </div>
          <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full rounded-full transition-all duration-500 ease-out",
                percentage > 100 ? "bg-destructive" : "bg-primary"
              )}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
