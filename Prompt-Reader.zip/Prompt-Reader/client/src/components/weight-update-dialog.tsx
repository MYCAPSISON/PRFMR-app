import { useState, useEffect } from "react";
import { useUpsertWeight } from "@/hooks/use-logs";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Scale, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
  TooltipPortal,
} from "@/components/ui/tooltip";

interface WeightUpdateDialogProps {
  date: string;
  existingLog?: any;
  userId: number;
}

export function WeightUpdateDialog({ date, existingLog, userId }: WeightUpdateDialogProps) {
  const [open, setOpen] = useState(false);
  const [weight, setWeight] = useState("");
  const { mutate: upsertWeight, isPending } = useUpsertWeight();
  const { toast } = useToast();

  // Reset weight when date or existingLog changes
  useEffect(() => {
    setWeight(existingLog?.weight?.toString() || "");
  }, [date, existingLog]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const weightNum = parseFloat(weight);
    
    if (isNaN(weightNum)) {
      toast({
        title: "Invalid weight",
        description: "Please enter a valid number for weight.",
        variant: "destructive",
      });
      return;
    }

    upsertWeight({
      userId,
      date,
      weight: weightNum,
    }, {
      onSuccess: () => {
        setOpen(false);
        toast({ title: "Weight saved" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2" data-testid="button-update-weight">
          <Scale className="h-4 w-4" />
          Update Weight
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] overflow-visible">
        <DialogHeader>
          <DialogTitle>Update Weight</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <Label htmlFor="weight">Current Weight (kg)</Label>
              <TooltipProvider>
                <Tooltip delayDuration={0}>
                  <TooltipTrigger asChild>
                    <button type="button" className="p-0.5 rounded-full hover:bg-secondary transition-colors">
                      <Info className="h-3.5 w-3.5 text-muted-foreground" />
                    </button>
                  </TooltipTrigger>
                  <TooltipPortal>
                    <TooltipContent 
                      side="top"
                      align="center"
                      sideOffset={8}
                      collisionPadding={12}
                      avoidCollisions
                      className="max-w-[260px] text-xs leading-snug z-[9999] whitespace-normal"
                    >
                      Weight can fluctuate day to day (water, sodium, glycogen, training load). Many athletes track weekly to focus on trends.
                    </TooltipContent>
                  </TooltipPortal>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Input
              id="weight"
              type="number"
              step="0.1"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="e.g. 75.5"
              required
              data-testid="input-weight"
            />
            <p className="text-xs text-muted-foreground leading-relaxed mt-2">
              Weight naturally fluctuates day to day (hydration, sodium, glycogen, training load). Many athletes prefer tracking weekly rather than daily—choose a frequency that supports your goals.
            </p>
          </div>

          <div className="pt-4 border-t space-y-4">
            <Button type="submit" className="w-full" disabled={isPending} data-testid="button-save-weight">
              {isPending ? "Saving..." : "Save Weight"}
            </Button>
            <p className="text-[10px] text-muted-foreground italic text-center">
              Fitness tracking tool only — not medical advice.
            </p>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
