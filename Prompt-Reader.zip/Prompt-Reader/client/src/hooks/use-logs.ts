import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { insertLogSchema, insertFoodEntrySchema } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { getStoredUsername, useUser } from "./use-user";

export function useLogs() {
  const username = getStoredUsername();
  
  return useQuery({
    queryKey: [api.logs.list.path, username],
    queryFn: async () => {
      if (!username) return [];
      const url = buildUrl(api.logs.list.path, { username });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch logs");
      return api.logs.list.responses[200].parse(await res.json());
    },
    enabled: !!username,
  });
}

export function useCreateLog() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: z.infer<typeof insertLogSchema>) => {
      const res = await fetch(api.logs.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create log");
      return api.logs.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
      toast({
        title: "Log Saved",
        description: "Your daily progress has been recorded.",
      });
    },
  });
}

export function useUpdateLog() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<z.infer<typeof insertLogSchema>>) => {
      const url = buildUrl(api.logs.update.path, { id });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update log");
      return api.logs.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
      toast({
        title: "Log Updated",
        description: "Your changes have been saved.",
      });
    },
  });
}

export function useFoodEntries(date: string) {
  const username = getStoredUsername();
  
  return useQuery({
    queryKey: [api.food.list.path, username, date],
    queryFn: async () => {
      if (!username) return [];
      const url = buildUrl(api.food.list.path, { username, date });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch food entries");
      return api.food.list.responses[200].parse(await res.json());
    },
    enabled: !!username && !!date,
  });
}

export function useFoodEntriesRange(startDate: string, endDate: string) {
  const username = getStoredUsername();
  
  return useQuery({
    queryKey: ["/api/food-entries/range", username, startDate, endDate],
    queryFn: async () => {
      if (!username) return [];
      const res = await fetch(`/api/food-entries/range?username=${username}&start=${startDate}&end=${endDate}`, {
        cache: "no-store",
        headers: { "Cache-Control": "no-cache" }
      });
      if (!res.ok) throw new Error("Failed to fetch food entries range");
      return await res.json();
    },
    enabled: !!username && !!startDate && !!endDate,
    staleTime: 0,
    refetchOnMount: "always",
  });
}

export function useCreateFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: z.infer<typeof insertFoodEntrySchema>) => {
      const res = await fetch(api.food.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create food entry");
      return api.food.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.food.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/food-entries/range"] });
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
      toast({
        title: "Food Logged",
        description: "Item added to your daily log.",
      });
    },
  });
}

export function useUpdateFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<z.infer<typeof insertFoodEntrySchema>>) => {
      const res = await fetch(`/api/food/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update food entry");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.food.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/food-entries/range"] });
      toast({
        title: "Entry Updated",
        description: "Food item has been updated.",
      });
    },
  });
}

export function useDeleteFoodEntry() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.food.delete.path, { id });
      const res = await fetch(url, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete food entry");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.food.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/food-entries/range"] });
      queryClient.invalidateQueries({ queryKey: [api.logs.list.path] });
      toast({
        title: "Entry Removed",
        description: "Food item has been deleted.",
      });
    },
  });
}

export function useWeightsRange(startDate: string, endDate: string) {
  const username = getStoredUsername();
  
  return useQuery({
    queryKey: ["/api/weights/range", username, startDate, endDate],
    queryFn: async () => {
      if (!username) return [];
      const res = await fetch(`/api/weights/range?username=${username}&start=${startDate}&end=${endDate}`, {
        cache: "no-store",
        headers: { "Cache-Control": "no-cache" }
      });
      if (!res.ok) throw new Error("Failed to fetch weights range");
      return await res.json();
    },
    enabled: !!username && !!startDate && !!endDate,
    staleTime: 0,
    refetchOnMount: "always",
  });
}

export function useUpsertWeight() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { userId: number; date: string; weight: number }) => {
      const res = await fetch("/api/weights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to save weight");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weights/range"] });
      toast({
        title: "Weight Saved",
        description: "Your weight has been recorded.",
      });
    },
  });
}
