import { useEffect, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

interface TodayReminder {
  id: number;
  stackId: number;
  time: string;
  daysOfWeek: string[];
  enabled: boolean;
  stackName: string;
}

const POLL_INTERVAL_MS = 30000;
const TIME_WINDOW_SECONDS = 60;

function getDayOfWeek(): string {
  const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  return days[new Date().getDay()];
}

function getCurrentTimeMinutes(): string {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, "0");
  const minutes = now.getMinutes().toString().padStart(2, "0");
  return `${hours}:${minutes}`;
}

function timeToSeconds(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 3600 + m * 60;
}

function getTriggeredKey(reminderId: number): string {
  const today = new Date().toISOString().split("T")[0];
  return `reminder_triggered_${reminderId}_${today}`;
}

function hasTriggeredToday(reminderId: number): boolean {
  return localStorage.getItem(getTriggeredKey(reminderId)) === "true";
}

function markTriggeredToday(reminderId: number): void {
  localStorage.setItem(getTriggeredKey(reminderId), "true");
}

export function triggerReminderNotification(stackName: string, toast: ReturnType<typeof useToast>["toast"]) {
  toast({
    title: "Supplement Reminder",
    description: `Time to take your ${stackName} stack`,
  });

  if (typeof Notification !== "undefined" && Notification.permission === "granted") {
    try {
      new Notification("Supplement Reminder", {
        body: `Time to take your ${stackName} stack`,
        icon: "/favicon.ico",
      });
    } catch (e) {
      console.warn("Browser notification failed:", e);
    }
  }
}

export function useReminderEngine(username: string | undefined) {
  const { toast } = useToast();
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const checkReminders = useCallback(async () => {
    if (!username) return;

    try {
      const res = await fetch(`/api/reminders/today/${encodeURIComponent(username)}`);
      if (!res.ok) return;

      const reminders: TodayReminder[] = await res.json();
      const currentDay = getDayOfWeek();
      const currentTime = getCurrentTimeMinutes();
      const currentSeconds = timeToSeconds(currentTime);

      for (const reminder of reminders) {
        if (!reminder.enabled) continue;
        if (!reminder.daysOfWeek.includes(currentDay)) continue;
        if (hasTriggeredToday(reminder.id)) continue;

        const reminderSeconds = timeToSeconds(reminder.time);
        const diff = Math.abs(currentSeconds - reminderSeconds);

        if (diff <= TIME_WINDOW_SECONDS) {
          markTriggeredToday(reminder.id);
          triggerReminderNotification(reminder.stackName, toast);
        }
      }
    } catch (e) {
      console.warn("Reminder engine error:", e);
    }
  }, [username, toast]);

  useEffect(() => {
    if (!username) return;

    checkReminders();

    intervalRef.current = setInterval(checkReminders, POLL_INTERVAL_MS);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [username, checkReminders]);
}

export async function requestNotificationPermission(): Promise<NotificationPermission | null> {
  if (typeof Notification === "undefined") {
    return null;
  }
  
  if (Notification.permission === "granted") {
    return "granted";
  }
  
  if (Notification.permission === "denied") {
    return "denied";
  }
  
  try {
    const result = await Notification.requestPermission();
    return result;
  } catch (e) {
    console.warn("Notification permission request failed:", e);
    return null;
  }
}
