import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { insertUserSchema, type OnboardingData } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const USERNAME_KEY = "fitness_app_username";

// Helper to manage local session
export function getStoredUsername() {
  return localStorage.getItem(USERNAME_KEY);
}

export function setStoredUsername(username: string) {
  localStorage.setItem(USERNAME_KEY, username);
}

export function useUser() {
  const username = getStoredUsername();
  
  return useQuery({
    queryKey: [api.user.get.path, username],
    queryFn: async () => {
      if (!username) return null;
      const url = buildUrl(api.user.get.path, { username });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.user.get.responses[200].parse(await res.json());
    },
    enabled: !!username,
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (username: string) => {
      const res = await fetch(api.user.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username }),
      });
      if (!res.ok) throw new Error("Login failed");
      return api.user.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      setStoredUsername(data.username);
      queryClient.invalidateQueries({ queryKey: [api.user.get.path] });
      toast({
        title: "Welcome back",
        description: `Signed in as ${data.username}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useOnboard() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const username = getStoredUsername();

  return useMutation({
    mutationFn: async (data: OnboardingData) => {
      if (!username) throw new Error("No user session");
      
      const url = buildUrl(api.user.onboard.path, { username });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) throw new Error("Onboarding failed");
      return api.user.onboard.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.user.get.path] });
      toast({
        title: "Profile Updated",
        description: "Your nutrition targets have been calculated.",
      });
    },
  });
}
