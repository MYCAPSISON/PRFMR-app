import { Ingredient, getMicronutrientValue } from "@shared/utils";

export interface AMQSResult {
  score: number;
  tier: string;
  confidence: {
    score: number;
    label: string;
  };
  gaps: AMQSGap[];
}

export interface AMQSGap {
  key: string;
  displayName: string;
  intake: number;
  target: number;
  adequacy: number;
  unit: string;
  suggestion: string;
}

export interface UserProfile {
  sex: "male" | "female";
  age: number;
  diet: "omnivore" | "vegan";
}

const DEFAULT_PROFILE: UserProfile = {
  sex: "male",
  age: 25,
  diet: "omnivore",
};

interface NutrientDef {
  key: string;
  displayName: string;
  unit: string;
  weight: number;
  getTarget: (profile: UserProfile) => number;
}

const NUTRIENTS: NutrientDef[] = [
  { key: "iron_mg", displayName: "Iron", unit: "mg", weight: 2.0, getTarget: (p) => (p.sex === "female" ? 14.8 : 8.7) },
  { key: "calcium_mg", displayName: "Calcium", unit: "mg", weight: 2.0, getTarget: () => 700 },
  { key: "vitamin_d_ug", displayName: "Vitamin D", unit: "µg", weight: 2.0, getTarget: () => 10 },
  { key: "magnesium_mg", displayName: "Magnesium", unit: "mg", weight: 1.5, getTarget: (p) => (p.sex === "female" ? 270 : 300) },
  { key: "zinc_mg", displayName: "Zinc", unit: "mg", weight: 1.5, getTarget: (p) => (p.sex === "female" ? 7.0 : 9.5) },
  { key: "iodine_ug", displayName: "Iodine", unit: "µg", weight: 1.0, getTarget: () => 140 },
  { key: "selenium_ug", displayName: "Selenium", unit: "µg", weight: 1.0, getTarget: (p) => (p.sex === "female" ? 60 : 75) },
  { key: "folate_ug", displayName: "Folate", unit: "µg", weight: 1.0, getTarget: () => 200 },
  { key: "vitamin_b12_ug", displayName: "Vitamin B12", unit: "µg", weight: 1.0, getTarget: () => 1.5 },
  { key: "vitamin_c_mg", displayName: "Vitamin C", unit: "mg", weight: 1.0, getTarget: () => 40 },
  { key: "vitamin_a_ug", displayName: "Vitamin A", unit: "µg", weight: 1.0, getTarget: (p) => (p.sex === "female" ? 600 : 700) },
  { key: "potassium_mg", displayName: "Potassium", unit: "mg", weight: 1.0, getTarget: () => 3500 },
];

function getTier(score: number): string {
  if (score >= 90) return "Elite";
  if (score >= 75) return "Optimal";
  if (score >= 50) return "Good";
  if (score >= 30) return "Fair";
  return "Basic";
}

export function computeDailyAMQS(
  logEntries: any[],
  userProfile: UserProfile = DEFAULT_PROFILE,
  ingredientIndex: Ingredient[],
  supplementMicros?: Record<string, number>
): AMQSResult {
  const p = userProfile;
  let totalFull = 0;
  let totalPartial = 0;
  const intakes: Record<string, number> = {};
  NUTRIENTS.forEach(n => intakes[n.key] = 0);

  logEntries.forEach(entry => {
    // Find the ingredient data
    const ingredient = ingredientIndex.find(i => i.name === entry.name);
    if (!ingredient) {
      // For barcode/custom entries, we might not have all micro data
      // If we don't have ingredient reference, treat as zero micros for now
      // unless we extend the storage to keep them.
      return;
    }

    let nonNullCount = 0;
    NUTRIENTS.forEach(n => {
      const val = getMicronutrientValue(ingredient, `${n.key}_per_100g`);
      if (val !== null) {
        nonNullCount++;
        intakes[n.key] += (val * entry.grams) / 100;
      }
    });

    if (nonNullCount >= 8) totalFull++;
    else if (nonNullCount > 0) totalPartial++;
  });

  // Add supplement micronutrients
  if (supplementMicros) {
    for (const [key, value] of Object.entries(supplementMicros)) {
      if (intakes[key] !== undefined) {
        intakes[key] += value;
      }
    }
  }

  const totalCount = logEntries.length;
  const confidenceScore = totalCount === 0 ? 0 : Math.round((100 * (totalFull + 0.5 * totalPartial)) / totalCount);
  let confidenceLabel = "Low";
  if (confidenceScore >= 70) confidenceLabel = "High";
  else if (confidenceScore >= 40) confidenceLabel = "Medium";

  let sumWeightAdequacy = 0;
  let sumWeight = 0;

  const gaps: AMQSGap[] = NUTRIENTS.map(n => {
    const target = n.getTarget(p);
    const intake = intakes[n.key];
    const adequacy = Math.min(intake / target, 1);
    
    let weight = n.weight;
    if (n.key === "vitamin_b12_ug" && p.diet === "vegan") weight = 2.0;
    if (n.key === "iron_mg" && p.sex === "female") weight = 2.5;

    sumWeightAdequacy += weight * adequacy;
    sumWeight += weight;

    // Find best suggestion
    const bestFood = [...ingredientIndex].sort((a, b) => {
      const valA = getMicronutrientValue(a, `${n.key}_per_100g`) || 0;
      const valB = getMicronutrientValue(b, `${n.key}_per_100g`) || 0;
      return valB - valA;
    })[0];

    return {
      key: n.key,
      displayName: n.displayName,
      intake,
      target,
      adequacy,
      unit: n.unit,
      suggestion: bestFood?.name || "N/A"
    };
  });

  const score = sumWeight === 0 ? 0 : Math.round((100 * sumWeightAdequacy) / sumWeight);
  
  const sortedGaps = [...gaps].sort((a, b) => a.adequacy - b.adequacy).slice(0, 3);

  return {
    score,
    tier: getTier(score),
    confidence: { score: confidenceScore, label: confidenceLabel },
    gaps: sortedGaps
  };
}

export function computeWeeklyAMQS(dailyResults: AMQSResult[]): { score: number; tier: string } {
  if (dailyResults.length === 0) return { score: 0, tier: "Basic" };

  // Simple average of daily scores - ensures monotonic increase as more days are filled
  // Days without entries are treated as score 0, so filling more days always helps
  const avgScore = dailyResults.reduce((acc, r) => acc + r.score, 0) / dailyResults.length;
  const finalScore = Math.min(100, Math.max(0, Math.round(avgScore)));
  
  return { score: finalScore, tier: getTier(finalScore) };
}
