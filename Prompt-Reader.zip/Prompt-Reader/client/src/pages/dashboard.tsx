import { useEffect, useState } from "react";
import { useUser } from "@/hooks/use-user";
import { useLogs, useCreateLog, useUpdateLog, useFoodEntries, useCreateFoodEntry, useDeleteFoodEntry, useFoodEntriesRange, useWeightsRange, useUpsertWeight, useUpdateFoodEntry } from "@/hooks/use-logs";
import { Layout } from "@/components/layout";
import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flame, Beef, Wheat, Droplets, Plus, Scale, Trash2, Utensils, Search, Leaf, ChevronLeft, ChevronRight, Calendar, Pencil, Coffee, Sun, Moon, Cookie, Pill, Check, X } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { MealType } from "@shared/schema";
import { format, parseISO, subDays, addDays } from "date-fns";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";

import { getMicronutrientValue } from "@shared/utils";
import { computeDailyAMQS, computeWeeklyAMQS } from "@/lib/amqs";

import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TooltipProvider, Tooltip as UITooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { ShieldCheck, Info } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

import { Html5Qrcode } from "html5-qrcode";

import { WeightUpdateDialog } from "@/components/weight-update-dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import type { SupplementStack, StackReminder, Supplement, SupplementLog, StackSupplement } from "@shared/schema";
import { Link } from "wouter";

// Type for scheduled stacks API response - now flat slots
interface ScheduledSlot {
  stackId: number;
  stackName: string;
  reminderId: number;
  time: string;
  supplementId: number;
  supplementName: string;
  doseAmount: number | null;
  doseUnit: string | null;
}

function TodaysSupplements({ userId, username, selectedDate }: { userId: number; username: string; selectedDate: string }) {
  const displayDate = format(parseISO(selectedDate), "MMM d");
  
  // Use the new flat slots endpoint
  const { data: scheduledSlots = [], isLoading } = useQuery<ScheduledSlot[]>({
    queryKey: ["/api/stacks/scheduled", username, selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/stacks/scheduled?username=${encodeURIComponent(username)}&date=${selectedDate}`);
      if (!res.ok) return [];
      return res.json();
    },
  });

  // Get taken slot keys for this date
  const { data: intakesData } = useQuery<{ takenSlotKeys: string[] }>({
    queryKey: ["/api/supplement-intakes", username, selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/supplement-intakes?username=${encodeURIComponent(username)}&date=${selectedDate}`);
      if (!res.ok) return { takenSlotKeys: [] };
      return res.json();
    },
  });
  
  const takenSlotKeys = new Set(intakesData?.takenSlotKeys || []);

  // Toggle supplement taken status (also creates log for AMQS)
  const toggleMutation = useMutation({
    mutationFn: async (data: { supplementId: number; stackId: number; reminderId: number; taken: boolean }) => {
      // Update intake for persistence (per-slot)
      const intakeResult = await apiRequest("POST", "/api/supplement-intakes", {
        userId,
        supplementId: data.supplementId,
        stackId: data.stackId,
        reminderId: data.reminderId,
        date: selectedDate,
        taken: data.taken,
      });
      
      // Also create/update supplement log for AMQS tracking
      if (data.taken) {
        await apiRequest("POST", "/api/supplement-logs", {
          userId,
          supplementId: data.supplementId,
          stackId: data.stackId,
          date: selectedDate,
          time: format(new Date(), "HH:mm"),
          taken: true,
        });
      }
      
      return intakeResult;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/supplement-intakes", username, selectedDate] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplement-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplement-micros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/supplement-micros-range"] });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Stacks — {displayDate}
            </CardTitle>
            <CardDescription>Loading...</CardDescription>
          </div>
        </CardHeader>
      </Card>
    );
  }

  // Helper to generate slot key
  const getSlotKey = (slot: ScheduledSlot) => `${slot.stackId}-${slot.reminderId}-${slot.supplementId}`;

  if (scheduledSlots.length === 0) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Stacks — {displayDate}
            </CardTitle>
            <CardDescription>
              Supplement stacks scheduled for this day
            </CardDescription>
          </div>
          <Link href="/stacks">
            <Button variant="ghost" size="sm">Manage</Button>
          </Link>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No stacks scheduled for this day. Create stacks and set reminders to see them here.</p>
        </CardContent>
      </Card>
    );
  }

  const takenCount = scheduledSlots.filter(s => takenSlotKeys.has(getSlotKey(s))).length;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Pill className="h-5 w-5" />
            Stacks — {displayDate}
          </CardTitle>
          <CardDescription>
            Scheduled for this day ({takenCount} of {scheduledSlots.length} taken)
          </CardDescription>
        </div>
        <Link href="/stacks">
          <Button variant="ghost" size="sm">Manage</Button>
        </Link>
      </CardHeader>
      <CardContent className="space-y-2">
        {scheduledSlots.map((slot) => {
          const slotKey = getSlotKey(slot);
          const taken = takenSlotKeys.has(slotKey);
          const doseLabel = slot.doseAmount && slot.doseUnit 
            ? `${slot.doseAmount} ${slot.doseUnit}` 
            : null;
          
          return (
            <div
              key={slotKey}
              className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                taken ? "bg-emerald-500/10 border-emerald-500/30" : "bg-secondary/30"
              }`}
              data-testid={`supp-slot-${slotKey}`}
            >
              <div className="flex-1">
                <p className={`font-medium text-sm ${taken ? "line-through text-muted-foreground" : ""}`}>
                  {slot.supplementName}
                  {doseLabel && <span className="text-muted-foreground font-normal"> ({doseLabel})</span>}
                </p>
                <p className="text-xs text-muted-foreground">
                  {slot.stackName} at {slot.time}
                </p>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant={taken ? "default" : "outline"}
                  className={`h-8 w-8 ${taken ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
                  onClick={() => toggleMutation.mutate({ 
                    supplementId: slot.supplementId,
                    stackId: slot.stackId,
                    reminderId: slot.reminderId,
                    taken: !taken 
                  })}
                  disabled={toggleMutation.isPending}
                  data-testid={`button-take-${slotKey}`}
                >
                  {taken ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          );
        })}
        <p className="text-[10px] text-muted-foreground italic pt-2">
          Personal tracking only. Not medical advice.
        </p>
      </CardContent>
    </Card>
  );
}

function AMQSCard({ daily, weekly }: { daily: any, weekly: any }) {
  const hasWeeklyData = weekly && typeof weekly.score === 'number';

  if (!daily) return (
    <div className="bg-card border rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-semibold">Micronutrient Quality</h3>
        <ShieldCheck className="h-5 w-5 text-muted-foreground/30" />
      </div>
      <p className="text-sm text-muted-foreground">Log foods to see your athlete micronutrient score (AMQS).</p>
    </div>
  );

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Elite': return 'bg-emerald-500 text-white';
      case 'Optimal': return 'bg-blue-500 text-white';
      case 'Good': return 'bg-amber-500 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  return (
    <div className="bg-card border rounded-xl p-6 shadow-sm space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Micronutrient Quality</h3>
          <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Athlete Score (AMQS)</p>
        </div>
        <ShieldCheck className="h-5 w-5 text-primary" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Daily Score</p>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">{daily.score}</span>
            <Badge className={getTierColor(daily.tier)}>{daily.tier}</Badge>
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Weekly Average</p>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-muted-foreground">
              {hasWeeklyData ? weekly.score : "—"}
            </span>
            <Badge variant="outline">
              {hasWeeklyData ? weekly.tier : "Not enough data"}
            </Badge>
          </div>
          {weekly?.score === 0 && (
            <p className="text-[10px] text-muted-foreground leading-tight">
              No food logged in the past 7 days.
            </p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-medium">Data Confidence</p>
          <div className="flex items-center gap-1">
             <Badge variant="secondary" className="text-[10px] px-1.5">{daily.confidence.label}</Badge>
             <TooltipProvider>
               <UITooltip>
                 <TooltipTrigger>
                   <Info className="h-3 w-3 text-muted-foreground" />
                 </TooltipTrigger>
                 <TooltipContent className="max-w-[200px] text-[11px]">
                    Based on how much of today's logged food has micronutrient data ({daily.confidence.score}%).
                 </TooltipContent>
               </UITooltip>
             </TooltipProvider>
          </div>
        </div>
        <Progress value={daily.confidence.score} className="h-1.5" />
      </div>

      {daily.gaps.length > 0 && (
        <div className="space-y-3 pt-2">
          <p className="text-xs font-bold uppercase text-muted-foreground tracking-tight">Top Micronutrient Gaps</p>
          <div className="space-y-2">
            {daily.gaps.map((gap: any) => (
              <div key={gap.key} className="text-xs flex flex-col gap-1 p-2 rounded bg-secondary/20">
                <div className="flex justify-between">
                  <span className="font-medium">{gap.displayName}</span>
                  <span className="text-muted-foreground">{Math.round(gap.adequacy * 100)}% of target</span>
                </div>
                <p className="text-[10px] text-muted-foreground">
                  Try adding: <span className="text-foreground font-medium">{gap.suggestion}</span>
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="pt-2 border-t">
        <p className="text-[10px] text-muted-foreground italic leading-tight">
          Estimates from logged foods; not medical advice. Blood tests assess deficiencies.
        </p>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: user, isLoading: userLoading } = useUser();
  const { data: logs, isLoading: logsLoading } = useLogs();
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const { data: foodEntries, isLoading: foodLoading } = useFoodEntries(selectedDate);
  const [, setLocation] = useLocation();
  
  // Date range for weekly AMQS (7 days ending on selected date)
  const weekStart = format(subDays(parseISO(selectedDate), 6), "yyyy-MM-dd");
  const { data: rangeEntries = [] } = useFoodEntriesRange(weekStart, selectedDate);
  
  // Fetch supplement micros for the week range
  const { data: rangeMicros = {} } = useQuery<Record<string, Record<string, number>>>({
    queryKey: ["/api/supplement-micros-range", user?.username, weekStart, selectedDate],
    enabled: !!user?.username,
    queryFn: async () => {
      const res = await fetch(`/api/supplement-micros-range/${encodeURIComponent(user!.username)}/${weekStart}/${selectedDate}`);
      if (!res.ok) return {};
      return res.json();
    }
  });
  
  // Weights for chart (last 30 days)
  const weightChartStart = format(subDays(parseISO(selectedDate), 30), "yyyy-MM-dd");
  const { data: weightsData = [] } = useWeightsRange(weightChartStart, selectedDate);
  // Fetch all ingredients for AMQS calculation
  const { data: ingredients = [] } = useQuery({
    queryKey: ["/api/ingredients"],
    queryFn: async () => {
      const res = await fetch("/api/ingredients");
      if (!res.ok) throw new Error("Failed to fetch ingredients");
      return res.json();
    }
  });
  
  // Fetch supplement micronutrients for selected date
  const { data: supplementMicros = {} } = useQuery<Record<string, number>>({
    queryKey: ["/api/supplement-micros", user?.username, selectedDate],
    enabled: !!user?.username,
    queryFn: async () => {
      const res = await fetch(`/api/supplement-micros/${encodeURIComponent(user!.username)}/${selectedDate}`);
      if (!res.ok) return {};
      return res.json();
    }
  });
  
  // Calculate AMQS (with supplement micronutrients)
  const dailyAMQS = (foodEntries?.length && ingredients?.length)
    ? computeDailyAMQS(foodEntries, undefined, ingredients, supplementMicros)
    : (Object.keys(supplementMicros).length > 0 && ingredients?.length)
      ? computeDailyAMQS([], undefined, ingredients, supplementMicros)
      : null;

  // Helper to normalize date strings (handles ISO timestamps or Date objects)
  const normalizeDateKey = (d: string | Date): string => {
    if (typeof d === 'string') {
      // If it's an ISO timestamp like "2026-01-11T00:00:00.000Z", extract just the date part
      if (d.includes('T')) {
        return d.split('T')[0];
      }
      return d;
    }
    return format(d, "yyyy-MM-dd");
  };

  // Weekly AMQS calculation - always compute for last 7 calendar days
  const weekDates = Array.from({ length: 7 }, (_, i) => 
    format(subDays(parseISO(selectedDate), 6 - i), "yyyy-MM-dd")
  );

  const dailyResults = ingredients?.length ? weekDates.map(date => {
    const dayEntries = rangeEntries.filter((e: any) => normalizeDateKey(e.date) === date);
    const dayMicros = rangeMicros[date] || {};
    const hasMicros = Object.keys(dayMicros).length > 0;
    
    if (dayEntries.length === 0 && !hasMicros) {
      return { score: 0, tier: "None", confidence: { score: 0, label: "No data" }, gaps: [] };
    }
    return computeDailyAMQS(dayEntries, undefined, ingredients, dayMicros);
  }) : [];

  const weeklyAMQS = ingredients?.length 
    ? computeWeeklyAMQS(dailyResults)
    : { score: 0, tier: "No data" };

  // Current date's log
  const selectedLog = logs?.find(l => l.date === selectedDate);
  
  // Date navigation functions
  const goToPreviousDay = () => setSelectedDate(format(subDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToNextDay = () => setSelectedDate(format(addDays(parseISO(selectedDate), 1), "yyyy-MM-dd"));
  const goToToday = () => setSelectedDate(format(new Date(), "yyyy-MM-dd"));
  const isToday = selectedDate === format(new Date(), "yyyy-MM-dd");
  useEffect(() => {
    if (!userLoading && !user) {
      setLocation("/");
    } else if (user && !user.targetCalories) {
      setLocation("/onboarding");
    }
  }, [user, userLoading, setLocation]);

  if (userLoading || logsLoading) {
    return <DashboardSkeleton />;
  }

  if (!user) return null;

  // Aggregate macros from food entries if they exist
  const aggregateMacros = foodEntries?.reduce((acc, entry) => ({
    calories: acc.calories + entry.calories,
    protein: acc.protein + entry.protein,
    carbs: acc.carbs + entry.carbs,
    fat: acc.fat + entry.fat,
    fibre: acc.fibre + (entry.fibre || 0),
  }), { calories: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 }) || { calories: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 };

  // Use manual log if it exists and has values, otherwise use aggregate
  const displayMacros = {
    calories: selectedLog?.calories || aggregateMacros.calories,
    protein: selectedLog?.protein || aggregateMacros.protein,
    carbs: selectedLog?.carbs || aggregateMacros.carbs,
    fat: selectedLog?.fat || aggregateMacros.fat,
    fibre: selectedLog?.fibre || aggregateMacros.fibre,
  };

  // Weight chart data from weights API
  const chartData = weightsData
    .map((w: any) => ({
      date: format(parseISO(w.date), "MMM d"),
      weight: w.weight
    }));


  return (
    <Layout>
      <div className="space-y-8">
        <AMQSCard daily={dailyAMQS} weekly={weeklyAMQS} />

        <Card>
          <CardHeader>
            <CardTitle>Nutrition Targets</CardTitle>
            <CardDescription>Calculated daily goals</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <div className="text-xl font-bold font-mono">{user.targetCalories}</div>
              <div className="text-xs text-muted-foreground">Calories</div>
            </div>
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <div className="text-xl font-bold font-mono">{user.targetProtein}g</div>
              <div className="text-xs text-muted-foreground">Protein</div>
            </div>
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <div className="text-xl font-bold font-mono">{user.targetCarbs}g</div>
              <div className="text-xs text-muted-foreground">Carbs</div>
            </div>
            <div className="p-4 bg-secondary/50 rounded-lg text-center">
              <div className="text-xl font-bold font-mono">{user.targetFat}g</div>
              <div className="text-xs text-muted-foreground">Fat</div>
            </div>
          </CardContent>
        </Card>

        {/* Date Navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" onClick={goToPreviousDay} data-testid="button-prev-day">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <Input 
                type="date" 
                value={selectedDate} 
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-[160px] font-medium"
                data-testid="input-date-picker"
              />
            </div>
            <Button variant="outline" size="icon" onClick={goToNextDay} data-testid="button-next-day">
              <ChevronRight className="h-4 w-4" />
            </Button>
            {!isToday && (
              <Button variant="ghost" size="sm" onClick={goToToday} data-testid="button-today">
                Today
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <WeightUpdateDialog 
              date={selectedDate} 
              userId={user.id} 
              existingLog={selectedLog}
            />
            <FoodEntryDialog date={selectedDate} existingEntries={foodEntries || []} />
            <LogEntryDialog 
              existingLog={selectedLog} 
              date={selectedDate}
            />
          </div>
        </div>

        {/* Header */}
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">
            Hello, {user.username}
          </h1>
          <p className="text-muted-foreground">
            {isToday ? "Here is your daily nutrition summary." : `Viewing ${format(parseISO(selectedDate), "MMMM d, yyyy")}`}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard
            title="Calories"
            value={displayMacros.calories}
            target={user.targetCalories || 2000}
            unit="kcal"
            icon={<Flame className="h-4 w-4" />}
            className="border-l-4 border-l-primary"
          />
          <StatCard
            title="Protein"
            value={displayMacros.protein}
            target={user.targetProtein || 150}
            unit="g"
            icon={<Beef className="h-4 w-4" />}
            className="border-l-4 border-l-blue-500"
          />
          <StatCard
            title="Carbs"
            value={displayMacros.carbs}
            target={user.targetCarbs || 200}
            unit="g"
            icon={<Wheat className="h-4 w-4" />}
            className="border-l-4 border-l-amber-500"
          />
          <StatCard
            title="Fat"
            value={displayMacros.fat}
            target={user.targetFat || 60}
            unit="g"
            icon={<Droplets className="h-4 w-4" />}
            className="border-l-4 border-l-yellow-500"
          />
          <StatCard
            title="Fibre"
            value={displayMacros.fibre}
            target={30} // Standard target
            unit="g"
            icon={<Leaf className="h-4 w-4" />}
            className="border-l-4 border-l-emerald-500"
          />
        </div>

        <TodaysSupplements userId={user.id} username={user.username} selectedDate={selectedDate} />

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
             {/* Weight Chart */}
            <div className="bg-card border rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">Weight Trend</h3>
                  <p className="text-sm text-muted-foreground">Last 7 recorded entries</p>
                </div>
                <div className="bg-secondary p-2 rounded-lg">
                  <Scale className="h-5 w-5 text-muted-foreground" />
                </div>
              </div>

              <div className="h-[250px] w-full">
                {chartData.length > 1 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <defs>
                        <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="date" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                        dy={10}
                      />
                      <YAxis 
                        domain={['auto', 'auto']} 
                        axisLine={false} 
                        tickLine={false}
                        tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                        width={30}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          borderRadius: '8px', 
                          border: '1px solid hsl(var(--border))',
                          boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                        }}
                        itemStyle={{ color: 'hsl(var(--foreground))' }}
                        labelStyle={{ color: 'hsl(var(--muted-foreground))', marginBottom: '0.25rem' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="weight" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorWeight)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                    Record more weight data to see trends
                  </div>
                )}
              </div>
            </div>

            {/* Food Entries List - Grouped by Meal */}
            <div className="bg-card border rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{isToday ? "Today's Meals" : `Meals — ${format(parseISO(selectedDate), "MMM d")}`}</h3>
                <Utensils className="h-5 w-5 text-muted-foreground/50" />
              </div>
              {foodLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : foodEntries && foodEntries.length > 0 ? (
                <MealGroupedEntries entries={foodEntries} allEntries={foodEntries} />
              ) : (
                <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
                  No food logged for this date.
                </div>
              )}
              <p className="text-[10px] text-muted-foreground mt-4 italic">
                Note: Nutrition values are approximate per 100g. Fibre applies mainly to plant foods.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Quick Actions / Today's Weight */}
            <div className="bg-card border rounded-xl p-6 shadow-sm h-fit">
              <h3 className="text-lg font-semibold mb-2">Current Weight</h3>
              <div className="text-4xl font-mono font-bold tracking-tight">
                {weightsData.find((w: any) => w.date === selectedDate)?.weight || user.currentWeight || "--"} <span className="text-lg font-sans font-medium text-muted-foreground">kg</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                {weightsData.find((w: any) => w.date === selectedDate)
                  ? (isToday ? "Recorded today" : `Recorded on ${format(parseISO(selectedDate), "MMM d")}`)
                  : (isToday ? "No weight recorded today" : "No weight recorded for this date")}
              </p>

              <div className="mt-8 space-y-3">
                <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
                    <p className="text-sm font-medium text-accent-foreground">
                      Tip: Consistency is key. Try to log your weight at the same time every morning.
                    </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function MealGroupedEntries({ entries, allEntries }: { entries: any[]; allEntries: any[] }) {
  // Group entries by meal type
  const breakfast = entries.filter(e => e.meal === "breakfast");
  const lunch = entries.filter(e => e.meal === "lunch" || !e.meal);
  const dinner = entries.filter(e => e.meal === "dinner");
  const snacks = entries.filter(e => e.meal === "snack");
  
  // Group snacks by snackIndex
  const snackGroups: Record<number, any[]> = {};
  snacks.forEach(s => {
    const idx = s.snackIndex ?? 1;
    if (!snackGroups[idx]) snackGroups[idx] = [];
    snackGroups[idx].push(s);
  });
  const sortedSnackIndices = Object.keys(snackGroups).map(Number).sort((a, b) => a - b);

  const renderEntry = (entry: any) => (
    <motion.div 
      key={entry.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex items-center justify-between p-3 rounded-lg border bg-secondary/30 group"
    >
      <div className="flex-1">
        <p className="font-medium">{entry.name} <span className="text-xs text-muted-foreground font-normal">({entry.grams}g)</span></p>
        <div className="flex gap-3 text-xs text-muted-foreground">
          <span>{entry.calories} kcal</span>
          <span>P: {entry.protein}g</span>
          <span>C: {entry.carbs}g</span>
          <span>F: {entry.fat}g</span>
          {entry.fibre !== null && entry.fibre !== undefined && entry.fibre > 0 && <span>Fi: {entry.fibre}g</span>}
        </div>
      </div>
      <div className="flex gap-1">
        <EditFoodDialog entry={entry} existingEntries={allEntries} />
        <DeleteFoodButton id={entry.id} />
      </div>
    </motion.div>
  );

  const renderMealSection = (label: string, Icon: any, items: any[]) => {
    if (items.length === 0) return null;
    return (
      <div className="space-y-2" key={label}>
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <Icon className="h-4 w-4" />
          <span>{label}</span>
          <Badge variant="secondary" className="text-[10px] px-1.5">{items.length}</Badge>
        </div>
        <AnimatePresence>
          {items.map(renderEntry)}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {renderMealSection("Breakfast", Coffee, breakfast)}
      {renderMealSection("Lunch", Sun, lunch)}
      {renderMealSection("Dinner", Moon, dinner)}
      {sortedSnackIndices.map(idx => (
        renderMealSection(`Snack #${idx}`, Cookie, snackGroups[idx])
      ))}
    </div>
  );
}

function FoodEntryDialog({ date, existingEntries = [] }: { date: string; existingEntries?: any[] }) {
  const [open, setOpen] = useState(false);
  const { mutate: createEntry, isPending } = useCreateFoodEntry();
  const { data: user } = useUser();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIngredient, setSelectedIngredient] = useState<any>(null);
  const [grams, setGrams] = useState("100");
  const [barcode, setBarcode] = useState("");
  const [barcodeResult, setBarcodeResult] = useState<any>(null);
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [barcodeError, setBarcodeError] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [scanner, setScanner] = useState<Html5Qrcode | null>(null);
  const [selectedMeal, setSelectedMeal] = useState<MealType>("lunch");
  const [selectedSnackIndex, setSelectedSnackIndex] = useState<number | null>(null);
  const [customMacros, setCustomMacros] = useState({
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    fibre: "",
  });

  // Calculate next available snack index for this date
  const existingSnackIndices = existingEntries
    .filter(e => e.meal === "snack" && e.snackIndex !== null)
    .map(e => e.snackIndex as number);
  const maxSnackIndex = existingSnackIndices.length > 0 ? Math.max(...existingSnackIndices) : 0;
  const nextSnackIndex = maxSnackIndex + 1;
  
  // Get unique snack indices for dropdown
  const uniqueSnackIndices = Array.from(new Set(existingSnackIndices)).sort((a, b) => a - b);

  useEffect(() => {
    return () => {
      if (scanner) {
        scanner.stop().catch(console.error);
      }
    };
  }, [scanner]);

  const startScan = async () => {
    setBarcodeError("");
    try {
      const html5QrCode = new Html5Qrcode("reader");
      setScanner(html5QrCode);
      setIsScanning(true);

      await html5QrCode.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: { width: 250, height: 150 },
        },
        (decodedText) => {
          setBarcode(decodedText);
          stopScan(html5QrCode);
          // Auto trigger lookup
          handleBarcodeLookupWithCode(decodedText);
        },
        () => {} // silent on failure to find qr
      );
    } catch (err: any) {
      console.error(err);
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        setBarcodeError("Camera access denied. Please enable permissions.");
      } else {
        setBarcodeError("Failed to start camera scan.");
      }
      setIsScanning(false);
    }
  };

  const stopScan = async (scannerInstance?: Html5Qrcode) => {
    const s = scannerInstance || scanner;
    if (s) {
      try {
        await s.stop();
        setScanner(null);
        setIsScanning(false);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleBarcodeLookupWithCode = async (codeToUse: string) => {
    if (!codeToUse) return;
    setIsLookingUp(true);
    setBarcodeError("");
    setBarcodeResult(null);
    try {
      const res = await fetch(`/api/food/barcode/${codeToUse}`);
      if (!res.ok) {
        setBarcodeError("Not found — use Custom entry or Whole Foods.");
        return;
      }
      const data = await res.json();
      setBarcodeResult(data);
      setGrams("100");
    } catch (err) {
      setBarcodeError("Error looking up barcode. Please try again.");
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleBarcodeLookup = () => handleBarcodeLookupWithCode(barcode);

  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !barcodeResult) return;

    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;

    createEntry({
      userId: user.id,
      date,
      name: barcodeResult.name,
      grams: parseInt(grams) || 100,
      calories: calculateMacro(barcodeResult.calories_kcal_100g),
      protein: calculateMacro(barcodeResult.protein_g_100g),
      carbs: calculateMacro(barcodeResult.carbs_g_100g),
      fat: calculateMacro(barcodeResult.fat_g_100g),
      fibre: calculateMacro(barcodeResult.fibre_g_100g || 0),
      meal: selectedMeal,
      snackIndex: snackIdx,
    }, {
      onSuccess: () => {
        setBarcode("");
        setBarcodeResult(null);
        setGrams("100");
        setSelectedMeal("lunch");
        setSelectedSnackIndex(null);
        setOpen(false);
      }
    });
  };

  const calculateMacro = (per100: number) => {
    const val = (per100 * parseFloat(grams)) / 100;
    return isNaN(val) ? 0 : Math.round(val);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;

    if (selectedIngredient) {
      createEntry({
        userId: user.id,
        date,
        name: selectedIngredient.name,
        grams: parseInt(grams) || 100,
        calories: calculateMacro(selectedIngredient.calories_per_100g),
        protein: calculateMacro(selectedIngredient.protein_g_per_100g),
        carbs: calculateMacro(selectedIngredient.carbs_g_per_100g),
        fat: calculateMacro(selectedIngredient.fat_g_per_100g),
        fibre: calculateMacro(selectedIngredient.fibre_g_per_100g || 0),
        meal: selectedMeal,
        snackIndex: snackIdx,
      }, {
        onSuccess: () => {
          setSearchTerm("");
          setSelectedIngredient(null);
          setGrams("100");
          setSelectedMeal("lunch");
          setSelectedSnackIndex(null);
          setOpen(false);
        }
      });
    } else if (searchTerm) {
      createEntry({
        userId: user.id,
        date,
        name: searchTerm,
        grams: parseInt(grams) || 100,
        calories: parseInt(customMacros.calories) || 0,
        protein: parseInt(customMacros.protein) || 0,
        carbs: parseInt(customMacros.carbs) || 0,
        fat: parseInt(customMacros.fat) || 0,
        fibre: parseInt(customMacros.fibre) || 0,
        meal: selectedMeal,
        snackIndex: snackIdx,
      }, {
        onSuccess: () => {
          setSearchTerm("");
          setCustomMacros({ calories: "", protein: "", carbs: "", fat: "", fibre: "" });
          setGrams("100");
          setSelectedMeal("lunch");
          setSelectedSnackIndex(null);
          setOpen(false);
        }
      });
    }
  };

  const { data: ingredients = [] } = useQuery({
    queryKey: ["/api/ingredients"],
    queryFn: async () => {
      const res = await fetch("/api/ingredients");
      if (!res.ok) throw new Error("Failed to fetch ingredients");
      return res.json();
    }
  });

  const filteredIngredients = searchTerm.length > 1 
    ? ingredients.filter((i: any) => i.name.toLowerCase().includes(searchTerm.toLowerCase()))
    : [];

  const handleSelect = (ingredient: any) => {
    setSelectedIngredient(ingredient);
    setSearchTerm(ingredient.name);
  };

  const quickAmounts = ["50", "100", "150", "200"];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Utensils className="mr-2 h-4 w-4" />
          Add Food
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] flex flex-col max-h-[90vh] p-0 overflow-visible">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>Add Food</DialogTitle>
        </DialogHeader>
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="px-6 pt-4 pb-2 space-y-3 shrink-0 border-b">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Add to meal</Label>
              <div className="flex gap-2">
                <Select value={selectedMeal} onValueChange={(v) => {
                  setSelectedMeal(v as MealType);
                  if (v !== "snack") setSelectedSnackIndex(null);
                }}>
                  <SelectTrigger className="w-[140px]" data-testid="select-meal">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast"><div className="flex items-center gap-2"><Coffee className="h-3.5 w-3.5" /> Breakfast</div></SelectItem>
                    <SelectItem value="lunch"><div className="flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Lunch</div></SelectItem>
                    <SelectItem value="dinner"><div className="flex items-center gap-2"><Moon className="h-3.5 w-3.5" /> Dinner</div></SelectItem>
                    <SelectItem value="snack"><div className="flex items-center gap-2"><Cookie className="h-3.5 w-3.5" /> Snack</div></SelectItem>
                  </SelectContent>
                </Select>
                {selectedMeal === "snack" && (
                  <Select 
                    value={selectedSnackIndex !== null ? selectedSnackIndex.toString() : "new"}
                    onValueChange={(v) => setSelectedSnackIndex(v === "new" ? null : parseInt(v))}
                  >
                    <SelectTrigger className="w-[120px]" data-testid="select-snack-index">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New Snack #{nextSnackIndex}</SelectItem>
                      {uniqueSnackIndices.map(idx => (
                        <SelectItem key={idx} value={idx.toString()}>Snack #{idx}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
          </div>
          <Tabs defaultValue="whole" className="w-full flex-1 flex flex-col overflow-hidden">
            <div className="px-6 pt-2 shrink-0">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="whole">Whole Food</TabsTrigger>
                <TabsTrigger value="barcode">Barcode</TabsTrigger>
                <TabsTrigger value="custom">Custom</TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-y-auto px-6">
              <TabsContent value="whole" className="space-y-6 py-4 mt-0">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <Label htmlFor="search">Search Ingredient</Label>
                <div className="relative mt-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="search" 
                    placeholder="Start typing (e.g. Chicken)..."
                    className="pl-10"
                    value={searchTerm} 
                    onChange={e => {
                      setSearchTerm(e.target.value);
                      if (selectedIngredient && e.target.value !== selectedIngredient.name) {
                        setSelectedIngredient(null);
                      }
                    }}
                  />
                </div>
                {filteredIngredients.length > 0 && !selectedIngredient && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-[200px] overflow-auto">
                    {filteredIngredients.map((i: any) => (
                      <button
                        key={i.name}
                        type="button"
                        className="w-full text-left px-4 py-2 text-sm hover:bg-accent transition-colors border-b last:border-0"
                        onClick={() => handleSelect(i)}
                      >
                        {i.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {selectedIngredient && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-4"
                >
                  <div className="space-y-2">
                    <Label htmlFor="grams">Amount (grams)</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="grams" 
                        type="number" 
                        value={grams} 
                        onChange={e => setGrams(e.target.value)}
                        className="flex-1"
                      />
                      <div className="flex gap-1">
                        {quickAmounts.map(amount => (
                          <Button 
                            key={amount}
                            type="button"
                            variant="outline"
                            size="sm"
                            className="px-2 h-9 text-xs"
                            onClick={() => setGrams(amount)}
                          >
                            {amount}g
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-secondary/30 rounded-lg space-y-2">
                    <div className="flex justify-between items-center border-b border-border pb-2">
                      <span className="text-sm font-medium">Estimated Nutrition</span>
                      <span className="text-lg font-bold text-primary">{calculateMacro(selectedIngredient.calories_per_100g)} kcal</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Prot</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.protein_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Carb</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.carbs_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Fat</div>
                        <div className="font-mono text-sm">{calculateMacro(selectedIngredient.fat_g_per_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold text-emerald-500">Fib</div>
                        <div className="font-mono text-sm text-emerald-600">{calculateMacro(selectedIngredient.fibre_g_per_100g || 0)}g</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

                  <div className="pt-2 pb-6 flex justify-end">
                    <Button type="submit" disabled={isPending || !selectedIngredient} className="w-full sm:w-auto">
                      {isPending ? "Logging..." : "Add Food"}
                    </Button>
                  </div>
                </form>
              </TabsContent>

              <TabsContent value="barcode" className="space-y-4 py-4 mt-0">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="barcode">Barcode</Label>
                <div className="flex gap-2">
                  <Input 
                    id="barcode" 
                    placeholder="Enter barcode manually" 
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                  />
                  <Button variant="default" onClick={handleBarcodeLookup} disabled={isLookingUp || !barcode}>
                    {isLookingUp ? "..." : "Lookup"}
                  </Button>
                </div>
                {barcodeError && <p className="text-xs text-destructive mt-1">{barcodeError}</p>}
              </div>

              <div className="space-y-3">
                {isScanning ? (
                  <Button variant="destructive" className="w-full min-h-10" onClick={() => stopScan()}>
                    Stop Scan
                  </Button>
                ) : (
                  <Button variant="outline" className="w-full min-h-10" onClick={startScan}>
                    Start Scan
                  </Button>
                )}
                <div id="reader" className={isScanning ? "block w-full overflow-hidden rounded-lg border bg-black" : "hidden"} />
                {isScanning && (
                  <p className="text-[10px] text-center text-muted-foreground animate-pulse">
                    Position barcode within the frame
                  </p>
                )}
              </div>

              {barcodeResult && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-4 pt-2 border-t"
                >
                  <div className="flex gap-4 items-start">
                    {barcodeResult.image_url && (
                      <div className="h-16 w-16 rounded-md overflow-hidden border bg-muted shrink-0">
                        <img 
                          src={barcodeResult.image_url} 
                          alt={barcodeResult.name} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    <div className="space-y-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{barcodeResult.name}</p>
                      <Label htmlFor="barcode-grams" className="text-xs">Amount (grams)</Label>
                      <div className="flex gap-2">
                        <Input 
                          id="barcode-grams" 
                          type="number" 
                          value={grams} 
                          onChange={e => setGrams(e.target.value)}
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-1 justify-center">
                    {quickAmounts.map(amount => (
                      <Button 
                        key={amount}
                        type="button"
                        variant="outline"
                        size="sm"
                        className="px-2 h-7 text-[10px]"
                        onClick={() => setGrams(amount)}
                      >
                        {amount}g
                      </Button>
                    ))}
                  </div>

                  <div className="p-4 bg-secondary/30 rounded-lg space-y-2">
                    <div className="flex justify-between items-center border-b border-border pb-2">
                      <span className="text-sm font-medium text-muted-foreground">Nutrition per {grams}g</span>
                      <span className="text-lg font-bold text-primary">{calculateMacro(barcodeResult.calories_kcal_100g)} kcal</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Prot</div>
                        <div className="font-mono text-sm">{calculateMacro(barcodeResult.protein_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Carb</div>
                        <div className="font-mono text-sm">{calculateMacro(barcodeResult.carbs_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold">Fat</div>
                        <div className="font-mono text-sm">{calculateMacro(barcodeResult.fat_g_100g)}g</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase font-bold text-emerald-500">Fib</div>
                        <div className="font-mono text-sm text-emerald-600">{calculateMacro(barcodeResult.fibre_g_100g || 0)}g</div>
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleBarcodeSubmit} disabled={isPending} className="w-full">
                    {isPending ? "Adding..." : "Add to Log"}
                  </Button>
                </motion.div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-6 py-4">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="custom-name">Food Name</Label>
                <Input 
                  id="custom-name" 
                  placeholder="Enter food name" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="p-4 bg-accent/5 border border-dashed rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="custom-grams" className="text-xs">Weight (g)</Label>
                    <Input 
                      id="custom-grams" 
                      type="number" 
                      value={grams} 
                      onChange={e => setGrams(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-calories" className="text-xs">Calories (kcal)</Label>
                    <Input 
                      id="custom-calories" 
                      type="number" 
                      value={customMacros.calories} 
                      onChange={e => setCustomMacros({...customMacros, calories: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-protein" className="text-xs">Protein (g)</Label>
                    <Input 
                      id="custom-protein" 
                      type="number" 
                      value={customMacros.protein} 
                      onChange={e => setCustomMacros({...customMacros, protein: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-carbs" className="text-xs">Carbs (g)</Label>
                    <Input 
                      id="custom-carbs" 
                      type="number" 
                      value={customMacros.carbs} 
                      onChange={e => setCustomMacros({...customMacros, carbs: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-fat" className="text-xs">Fat (g)</Label>
                    <Input 
                      id="custom-fat" 
                      type="number" 
                      value={customMacros.fat} 
                      onChange={e => setCustomMacros({...customMacros, fat: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="custom-fibre" className="text-xs">Fibre (g)</Label>
                    <Input 
                      id="custom-fibre" 
                      type="number" 
                      value={customMacros.fibre} 
                      onChange={e => setCustomMacros({...customMacros, fibre: e.target.value})}
                    />
                  </div>
                </div>
              </div>

                  <div className="pt-2 pb-6 flex justify-end">
                    <Button type="submit" disabled={isPending || !searchTerm} className="w-full sm:w-auto">
                      {isPending ? "Logging..." : "Add Food"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EditFoodDialog({ entry, existingEntries = [] }: { entry: any; existingEntries?: any[] }) {
  const [open, setOpen] = useState(false);
  const { mutate: updateEntry, isPending } = useUpdateFoodEntry();
  const [grams, setGrams] = useState(entry.grams.toString());
  const [calories, setCalories] = useState(entry.calories.toString());
  const [protein, setProtein] = useState(entry.protein.toString());
  const [carbs, setCarbs] = useState(entry.carbs.toString());
  const [fat, setFat] = useState(entry.fat.toString());
  const [fibre, setFibre] = useState((entry.fibre || 0).toString());
  const [selectedMeal, setSelectedMeal] = useState<MealType>(entry.meal || "lunch");
  const [selectedSnackIndex, setSelectedSnackIndex] = useState<number | null>(entry.snackIndex ?? null);

  // Calculate snack options
  const existingSnackIndices = existingEntries
    .filter(e => e.meal === "snack" && e.snackIndex !== null && e.id !== entry.id)
    .map(e => e.snackIndex as number);
  const maxSnackIndex = existingSnackIndices.length > 0 ? Math.max(...existingSnackIndices) : 0;
  const nextSnackIndex = Math.max(maxSnackIndex + 1, (entry.snackIndex ?? 0) + 1);
  const uniqueSnackIndices = Array.from(new Set([...existingSnackIndices, entry.snackIndex].filter(x => x !== null) as number[])).sort((a, b) => a - b);

  // Sync state when dialog opens or entry changes
  useEffect(() => {
    if (open) {
      setGrams(entry.grams.toString());
      setCalories(entry.calories.toString());
      setProtein(entry.protein.toString());
      setCarbs(entry.carbs.toString());
      setFat(entry.fat.toString());
      setFibre((entry.fibre || 0).toString());
      setSelectedMeal(entry.meal || "lunch");
      setSelectedSnackIndex(entry.snackIndex ?? null);
    }
  }, [open, entry]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const snackIdx = selectedMeal === "snack" 
      ? (selectedSnackIndex !== null ? selectedSnackIndex : nextSnackIndex)
      : null;
    
    updateEntry({
      id: entry.id,
      grams: parseInt(grams) || 100,
      calories: parseInt(calories) || 0,
      protein: parseInt(protein) || 0,
      carbs: parseInt(carbs) || 0,
      fat: parseInt(fat) || 0,
      fibre: parseInt(fibre) || 0,
      meal: selectedMeal,
      snackIndex: snackIdx,
    }, {
      onSuccess: () => setOpen(false)
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          size="icon" 
          variant="ghost" 
          className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
          data-testid={`button-edit-food-${entry.id}`}
        >
          <Pencil className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit: {entry.name}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Meal</Label>
            <div className="flex gap-2">
              <Select value={selectedMeal} onValueChange={(v) => {
                setSelectedMeal(v as MealType);
                if (v !== "snack") setSelectedSnackIndex(null);
              }}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakfast"><div className="flex items-center gap-2"><Coffee className="h-3.5 w-3.5" /> Breakfast</div></SelectItem>
                  <SelectItem value="lunch"><div className="flex items-center gap-2"><Sun className="h-3.5 w-3.5" /> Lunch</div></SelectItem>
                  <SelectItem value="dinner"><div className="flex items-center gap-2"><Moon className="h-3.5 w-3.5" /> Dinner</div></SelectItem>
                  <SelectItem value="snack"><div className="flex items-center gap-2"><Cookie className="h-3.5 w-3.5" /> Snack</div></SelectItem>
                </SelectContent>
              </Select>
              {selectedMeal === "snack" && (
                <Select 
                  value={selectedSnackIndex !== null ? selectedSnackIndex.toString() : "new"}
                  onValueChange={(v) => setSelectedSnackIndex(v === "new" ? null : parseInt(v))}
                >
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New Snack #{nextSnackIndex}</SelectItem>
                    {uniqueSnackIndices.map(idx => (
                      <SelectItem key={idx} value={idx.toString()}>Snack #{idx}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-grams">Grams</Label>
              <Input id="edit-grams" type="number" value={grams} onChange={(e) => setGrams(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-calories">Calories</Label>
              <Input id="edit-calories" type="number" value={calories} onChange={(e) => setCalories(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-protein">Protein (g)</Label>
              <Input id="edit-protein" type="number" value={protein} onChange={(e) => setProtein(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-carbs">Carbs (g)</Label>
              <Input id="edit-carbs" type="number" value={carbs} onChange={(e) => setCarbs(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-fat">Fat (g)</Label>
              <Input id="edit-fat" type="number" value={fat} onChange={(e) => setFat(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-fibre">Fibre (g)</Label>
              <Input id="edit-fibre" type="number" value={fibre} onChange={(e) => setFibre(e.target.value)} />
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={isPending} data-testid="button-save-edit-food">
            {isPending ? "Saving..." : "Save Changes"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteFoodButton({ id }: { id: number }) {
  const { mutate: deleteEntry, isPending } = useDeleteFoodEntry();
  return (
    <Button 
      size="icon" 
      variant="ghost" 
      disabled={isPending}
      className="opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
      onClick={() => deleteEntry(id)}
      data-testid={`button-delete-food-${id}`}
    >
      <Trash2 className="h-4 w-4" />
    </Button>
  );
}

function LogEntryDialog({ existingLog, date }: { existingLog?: any, date: string }) {
  const [open, setOpen] = useState(false);
  const { mutate: createLog, isPending: creating } = useCreateLog();
  const { mutate: updateLog, isPending: updating } = useUpdateLog();
  const { data: user } = useUser();

  const [formData, setFormData] = useState({
    weight: "",
    calories: "",
    protein: "",
    carbs: "",
    fat: "",
    fibre: "",
  });

  // Pre-fill
  useEffect(() => {
    if (existingLog) {
      setFormData({
        weight: existingLog.weight?.toString() || "",
        calories: existingLog.calories?.toString() || "",
        protein: existingLog.protein?.toString() || "",
        carbs: existingLog.carbs?.toString() || "",
        fat: existingLog.fat?.toString() || "",
        fibre: existingLog.fibre?.toString() || "",
      });
    } else if (user?.currentWeight) {
        setFormData(prev => ({...prev, weight: user.currentWeight?.toString() || "" }));
    }
  }, [existingLog, user, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      userId: user!.id,
      date,
      weight: formData.weight ? parseFloat(formData.weight) : undefined,
      calories: formData.calories ? parseInt(formData.calories) : 0,
      protein: formData.protein ? parseInt(formData.protein) : 0,
      carbs: formData.carbs ? parseInt(formData.carbs) : 0,
      fat: formData.fat ? parseInt(formData.fat) : 0,
      fibre: formData.fibre ? parseInt(formData.fibre) : 0,
    };

    if (existingLog) {
      updateLog({ id: existingLog.id, ...payload }, { onSuccess: () => setOpen(false) });
    } else {
      createLog(payload, { onSuccess: () => setOpen(false) });
    }
  };

  const isPending = creating || updating;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="shadow-lg shadow-primary/20">
          <Plus className="mr-2 h-4 w-4" />
          Update Summary
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{existingLog ? "Edit Summary" : "Log Summary"} ({format(parseISO(date), "MMM d")})</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <p className="text-xs text-muted-foreground mb-4">
            Note: Manually entering values here will override the calculated totals from your logged food items.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="calories">Total Calories (kcal)</Label>
              <Input 
                id="calories" 
                type="number" 
                value={formData.calories} 
                onChange={e => setFormData({...formData, calories: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input 
                id="weight" 
                type="number" 
                step="0.1"
                value={formData.weight} 
                onChange={e => setFormData({...formData, weight: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Macros & Fibre</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="protein" className="text-xs">Protein (g)</Label>
                <Input 
                  id="protein" 
                  type="number" 
                  value={formData.protein} 
                  onChange={e => setFormData({...formData, protein: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="carbs" className="text-xs">Carbs (g)</Label>
                <Input 
                  id="carbs" 
                  type="number" 
                  value={formData.carbs} 
                  onChange={e => setFormData({...formData, carbs: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="fat" className="text-xs">Fat (g)</Label>
                <Input 
                  id="fat" 
                  type="number" 
                  value={formData.fat} 
                  onChange={e => setFormData({...formData, fat: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="fibre" className="text-xs">Fibre (g)</Label>
                <Input 
                  id="fibre" 
                  type="number" 
                  value={formData.fibre} 
                  onChange={e => setFormData({...formData, fibre: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Summary"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DashboardSkeleton() {
  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          <Skeleton className="md:col-span-2 h-[300px] rounded-xl" />
          <Skeleton className="h-[300px] rounded-xl" />
        </div>
      </div>
    </Layout>
  );
}
