import { useState } from "react";
import { useLogin } from "@/hooks/use-user";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const { mutate, isPending } = useLogin();
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    
    mutate(username, {
      onSuccess: () => setLocation("/dashboard"),
    });
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Panel - Form */}
      <div className="flex items-center justify-center p-8 bg-background relative">
        <div className="w-full max-w-sm space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
              <Activity className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              Your fitness journey, simplified.
            </h1>
            <p className="mt-3 text-muted-foreground">
              Track nutrition, monitor progress, and master your health with minimal friction.
            </p>
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <label htmlFor="username" className="text-sm font-medium">
                Username
              </label>
              <Input
                id="username"
                type="text"
                placeholder="Enter a username (e.g., alex_fit)"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="h-12"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={isPending || !username}
              className="w-full h-12 text-base group"
            >
              {isPending ? "Signing in..." : "Start Tracking"}
              {!isPending && (
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              )}
            </Button>
            <p className="text-xs text-center text-muted-foreground pt-4">
              By continuing, you agree to our Terms of Service. 
              <br/>This is a demo application. No password required.
            </p>
          </motion.form>
        </div>
      </div>

      {/* Right Panel - Visual */}
      <div className="hidden lg:block relative bg-muted overflow-hidden">
        {/* Abstract shapes or a nice image could go here */}
        <div className="absolute inset-0 bg-zinc-900">
            {/* unsplash gym minimalist aesthetics */}
           <img 
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop"
            alt="Gym aesthetics"
            className="w-full h-full object-cover opacity-50 mix-blend-overlay"
           />
           <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-12">
             <blockquote className="text-white font-display text-2xl max-w-md">
               "The only bad workout is the one that didn't happen."
             </blockquote>
           </div>
        </div>
      </div>
    </div>
  );
}
