import { useState } from "react";
import { useOnboard } from "@/hooks/use-user";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronRight, ChevronLeft, Check } from "lucide-react";
import type { OnboardingData } from "@shared/schema";
import { useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { api } from "@shared/routes";
import { getStoredUsername } from "@/hooks/use-user";

const STEPS = ["Basics", "Body Metrics", "Lifestyle", "Goal"];

export default function OnboardingPage() {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState<Partial<OnboardingData>>({
    experienceLevel: "beginner",
    activityLevel: "moderate",
    goal: "fat_loss",
  });
  
  const { mutate, isPending } = useOnboard();
  const [, setLocation] = useLocation();

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep(s => s + 1);
    } else if (step === STEPS.length) {
      // Navigate to dashboard after completion - use window.location for reliability
      const username = getStoredUsername();
      queryClient.invalidateQueries({ queryKey: [api.user.get.path, username] });
      window.location.href = "/dashboard";
    } else {
      mutate(formData as OnboardingData, {
        onSuccess: () => {
          // Move to success screen
          setStep(STEPS.length);
        },
      });
    }
  };

  const handleBack = () => {
    setStep(s => Math.max(0, s - 1));
  };

  const updateField = (key: keyof OnboardingData, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="mb-8">
          <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
            <span>{step === STEPS.length ? "Setup Complete" : `Step ${step + 1} of ${STEPS.length}`}</span>
            <span>{step === STEPS.length ? "Success" : STEPS[step]}</span>
          </div>
          <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-primary"
              initial={{ width: 0 }}
              animate={{ width: `${step === STEPS.length ? 100 : ((step + 1) / STEPS.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        <Card className="border-none shadow-xl shadow-black/5">
          <CardContent className="p-6 sm:p-8 relative overflow-visible">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 min-h-[300px] overflow-visible"
              >
                {step === 0 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">The Basics</h2>
                      <p className="text-muted-foreground">Let's start with some simple details.</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Age</Label>
                        <Input 
                          type="number" 
                          placeholder="Years" 
                          value={formData.age || ""} 
                          onChange={(e) => updateField("age", parseInt(e.target.value) || 0)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Gender</Label>
                        <RadioGroup 
                          value={formData.gender ?? undefined} 
                          onValueChange={(v) => updateField("gender", v)}
                          className="grid grid-cols-2 gap-4"
                        >
                          <div>
                            <RadioGroupItem value="male" id="male" className="peer sr-only" />
                            <Label 
                              htmlFor="male"
                              className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                            >
                              Male
                            </Label>
                          </div>
                          <div>
                            <RadioGroupItem value="female" id="female" className="peer sr-only" />
                            <Label 
                              htmlFor="female"
                              className="flex items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                            >
                              Female
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </div>
                )}

                {step === 1 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Body Metrics</h2>
                      <p className="text-muted-foreground">This helps us calculate your baseline.</p>
                    </div>

                    <div className="grid gap-6">
                      <div className="space-y-2">
                        <Label>Height (cm)</Label>
                        <Input 
                          type="number" 
                          placeholder="e.g. 175" 
                          value={formData.height || ""} 
                          onChange={(e) => updateField("height", parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Current Weight (kg)</Label>
                        <Input 
                          type="number" 
                          step="0.1"
                          placeholder="e.g. 70.5" 
                          value={formData.currentWeight || ""} 
                          onChange={(e) => updateField("currentWeight", parseFloat(e.target.value) || 0)}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-6">
                     <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Lifestyle</h2>
                      <p className="text-muted-foreground">Be honest - this affects your calorie needs.</p>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Activity Level</Label>
                        <Select 
                          value={formData.activityLevel ?? undefined} 
                          onValueChange={(v) => updateField("activityLevel", v)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue placeholder="Select activity level" />
                          </SelectTrigger>
                          <SelectContent position="popper" side="bottom" align="start" sideOffset={6} className="z-[9999]">
                            <SelectItem value="sedentary">Sedentary (Office job)</SelectItem>
                            <SelectItem value="light">Lightly Active (1-3 days/week)</SelectItem>
                            <SelectItem value="moderate">Moderately Active (3-5 days/week)</SelectItem>
                            <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                            <SelectItem value="very_active">Very Active (Physical job)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Experience Level</Label>
                        <Select 
                          value={formData.experienceLevel ?? undefined} 
                          onValueChange={(v) => updateField("experienceLevel", v)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue placeholder="Select experience" />
                          </SelectTrigger>
                          <SelectContent position="popper" side="bottom" align="start" sideOffset={6} className="z-[9999]">
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">Primary Goal</h2>
                      <p className="text-muted-foreground">What are you aiming for?</p>
                    </div>

                    <RadioGroup 
                      value={formData.goal ?? undefined} 
                      onValueChange={(v) => updateField("goal", v)}
                      className="space-y-3"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="fat_loss" id="fat_loss" className="peer sr-only" />
                        <Label 
                          htmlFor="fat_loss"
                          className="flex flex-1 items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-1 peer-data-[state=checked]:ring-primary cursor-pointer transition-all"
                        >
                          <div>
                            <div className="font-semibold">Fat Loss</div>
                            <div className="text-xs text-muted-foreground">Focus on calorie deficit</div>
                          </div>
                          <Check className="h-4 w-4 opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                )}

                {step === 4 && (
                  <div className="space-y-6 flex flex-col items-center justify-center text-center py-8">
                    <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                      <Check className="h-8 w-8 text-primary" />
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-2xl font-display font-bold">You're All Set!</h2>
                      <p className="text-muted-foreground">Your personalized nutrition plan is ready. Let's start tracking your progress.</p>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-between mt-8 pt-4 border-t">
              {step < 4 ? (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={handleBack} 
                    disabled={step === 0}
                    className="text-muted-foreground"
                  >
                    <ChevronLeft className="mr-2 h-4 w-4" /> Back
                  </Button>
                  <Button onClick={handleNext} disabled={isPending}>
                    {step === STEPS.length - 1 ? (isPending ? "Calculating..." : "Complete Setup") : "Next Step"}
                    {step !== STEPS.length - 1 && <ChevronRight className="ml-2 h-4 w-4" />}
                  </Button>
                </>
              ) : (
                <Button onClick={handleNext} className="w-full">
                  Go to Dashboard <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
