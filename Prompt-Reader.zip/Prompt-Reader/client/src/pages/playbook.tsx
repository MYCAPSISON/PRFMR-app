import { Layout } from "@/components/layout";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, Target, Utensils, Scale } from "lucide-react";

export default function Playbook() {
  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-display font-bold">The Playbook</h1>
          <p className="text-lg text-muted-foreground">
            Core principles for sustainable fat loss and health. No fluff, just science.
          </p>
        </div>

        <div className="grid gap-6">
          <Card className="border-l-4 border-l-accent">
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <div className="p-2 bg-accent/10 rounded-lg">
                <Target className="h-6 w-6 text-accent" />
              </div>
              <CardTitle className="text-xl">Energy Balance is King</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              Weight loss is fundamentally driven by a calorie deficit. If you consume fewer calories than you burn, you will lose weight. All diets (Keto, Paleo, IF) work via this mechanism. We calculate your targets to put you in a sustainable deficit.
            </CardContent>
          </Card>

          <Card>
             <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <div className="p-2 bg-secondary rounded-lg">
                <Utensils className="h-6 w-6 text-foreground" />
              </div>
              <CardTitle className="text-xl">Macronutrients Matter</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="protein">
                  <AccordionTrigger>Protein (The Builder)</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Essential for muscle retention during fat loss. High satiety helps control hunger. Aim for 1.6g to 2.2g per kg of lean body mass.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="fats">
                  <AccordionTrigger>Fats (The Hormonal Regulator)</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Crucial for hormone production and vitamin absorption. Don't drop too low (below 0.6g/kg). Choose healthy sources like olive oil, nuts, and avocados.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="carbs">
                  <AccordionTrigger>Carbohydrates (The Fuel)</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Your body's preferred energy source for high-intensity activity. Not inherently fattening. Adjust intake based on your activity level.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <div className="p-2 bg-secondary rounded-lg">
                <Scale className="h-6 w-6 text-foreground" />
              </div>
              <CardTitle className="text-xl">Weight Fluctuations</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground space-y-4">
              <p>
                Your weight will fluctuate daily due to water retention, sodium intake, carb intake, and digestion. Do not panic if the scale goes up one day.
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Weigh yourself daily under the same conditions (morning, after bathroom).</li>
                <li>Focus on the <strong>weekly average</strong> trend, not single data points.</li>
                <li>If the trend is flat for 2+ weeks, slightly lower calories.</li>
              </ul>
            </CardContent>
          </Card>
          
           <Card>
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <div className="p-2 bg-secondary rounded-lg">
                <Lightbulb className="h-6 w-6 text-foreground" />
              </div>
              <CardTitle className="text-xl">Actionable Habits</CardTitle>
            </CardHeader>
            <CardContent>
               <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="font-mono text-xl font-bold text-accent">01</div>
                  <div>
                    <h4 className="font-semibold">Track Accurately</h4>
                    <p className="text-sm text-muted-foreground">Guesstimating usually leads to underestimating intake by 30-50%. Use a food scale whenever possible.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="font-mono text-xl font-bold text-accent">02</div>
                  <div>
                    <h4 className="font-semibold">Prioritize Sleep</h4>
                    <p className="text-sm text-muted-foreground">Poor sleep increases hunger hormones (ghrelin) and decreases satiety hormones (leptin).</p>
                  </div>
                </div>
                 <div className="flex gap-4">
                  <div className="font-mono text-xl font-bold text-accent">03</div>
                  <div>
                    <h4 className="font-semibold">Walk More</h4>
                    <p className="text-sm text-muted-foreground">NEAT (Non-Exercise Activity Thermogenesis) burns more calories than gym sessions for most people. Aim for 8-10k steps.</p>
                  </div>
                </div>
               </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="text-center text-xs text-muted-foreground py-8">
            Disclaimer: This information is for educational purposes only and does not constitute medical advice. Consult a healthcare professional before starting any diet or exercise program.
        </div>
      </div>
    </Layout>
  );
}
