import { useUser, useOnboard } from "@/hooks/use-user";
import { useLogs } from "@/hooks/use-logs";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Settings, UserCircle } from "lucide-react";
import { useLocation } from "wouter";
import { WeightUpdateDialog } from "@/components/weight-update-dialog";
import { format } from "date-fns";

export default function Profile() {
  const { data: user, isLoading } = useUser();
  const { data: logs } = useLogs();
  const [, setLocation] = useLocation();
  const today = format(new Date(), "yyyy-MM-dd");
  const todaysLog = logs?.find(l => l.date === today);

  if (isLoading) {
    return (
      <Layout>
        <Skeleton className="h-[200px] w-full rounded-xl" />
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4 pb-4 border-b">
            <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
                <UserCircle className="h-12 w-12 text-muted-foreground" />
            </div>
            <div>
                <h1 className="text-2xl font-display font-bold">{user.username}</h1>
                <p className="text-muted-foreground capitalize">{user.experienceLevel} • {user.goal?.replace('_', ' ')}</p>
            </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <div className="space-y-1.5">
              <CardTitle>Current Metrics</CardTitle>
              <CardDescription>Based on your latest update</CardDescription>
            </div>
            <WeightUpdateDialog 
              date={today} 
              userId={user.id} 
              existingLog={todaysLog}
            />
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
             <div className="space-y-1">
                <Label className="text-muted-foreground">Height</Label>
                <div className="text-lg font-medium">{user.height} cm</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Weight</Label>
                <div className="text-lg font-medium">{user.currentWeight} kg</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Age</Label>
                <div className="text-lg font-medium">{user.age}</div>
             </div>
             <div className="space-y-1">
                <Label className="text-muted-foreground">Activity</Label>
                <div className="text-lg font-medium capitalize">{user.activityLevel?.replace('_', ' ')}</div>
             </div>
          </CardContent>
        </Card>

         <Card>
          <CardHeader>
            <CardTitle>Nutrition Targets</CardTitle>
            <CardDescription>Calculated daily goals</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-4">
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetCalories}</div>
                <div className="text-xs text-muted-foreground">Calories</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetProtein}g</div>
                <div className="text-xs text-muted-foreground">Protein</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetCarbs}g</div>
                <div className="text-xs text-muted-foreground">Carbs</div>
             </div>
             <div className="p-4 bg-secondary/50 rounded-lg text-center">
                <div className="text-xl font-bold font-mono">{user.targetFat}g</div>
                <div className="text-xs text-muted-foreground">Fat</div>
             </div>
          </CardContent>
        </Card>

        <div className="flex justify-end pt-4">
             <Button variant="outline" onClick={() => setLocation("/onboarding")}>
                <Settings className="mr-2 h-4 w-4" /> Recalculate Goals
             </Button>
        </div>
      </div>
    </Layout>
  );
}
