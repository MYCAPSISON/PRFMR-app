import { useState, useEffect } from "react";
import { useUser } from "@/hooks/use-user";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { AlertTriangle, Plus, Pencil, Trash2, Layers, Clock, Bell, X, Check, Volume2, BellRing } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Supplement, SupplementStack, StackSupplement, StackReminder } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";
import { triggerReminderNotification, requestNotificationPermission } from "@/hooks/use-reminder-engine";

const DAYS_OF_WEEK = [
  { key: "monday", label: "Mon" },
  { key: "tuesday", label: "Tue" },
  { key: "wednesday", label: "Wed" },
  { key: "thursday", label: "Thu" },
  { key: "friday", label: "Fri" },
  { key: "saturday", label: "Sat" },
  { key: "sunday", label: "Sun" },
];

export default function Stacks() {
  const { data: user, isLoading: userLoading } = useUser();
  const { toast } = useToast();
  const [addStackOpen, setAddStackOpen] = useState(false);
  const [editStackOpen, setEditStackOpen] = useState(false);
  const [editingStack, setEditingStack] = useState<SupplementStack | null>(null);
  const [manageSupplementsOpen, setManageSupplementsOpen] = useState(false);
  const [managingStackId, setManagingStackId] = useState<number | null>(null);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [reminderStackId, setReminderStackId] = useState<number | null>(null);
  const [disclaimerOpen, setDisclaimerOpen] = useState(false);
  const [pendingReminderStackId, setPendingReminderStackId] = useState<number | null>(null);

  const { data: stacks = [], isLoading: stacksLoading } = useQuery<SupplementStack[]>({
    queryKey: ["/api/stacks", user?.username],
    enabled: !!user?.username,
    queryFn: async () => {
      const res = await fetch(`/api/stacks/${encodeURIComponent(user!.username)}`);
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: supplements = [] } = useQuery<Supplement[]>({
    queryKey: ["/api/supplements", user?.username],
    enabled: !!user?.username,
    queryFn: async () => {
      const res = await fetch(`/api/supplements/${encodeURIComponent(user!.username)}`);
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: disclaimerAccepted } = useQuery<{ accepted: boolean; acceptedAt?: string }>({
    queryKey: ["/api/disclaimer", user?.username, "supplement_reminders"],
    enabled: !!user?.username,
    queryFn: async () => {
      const res = await fetch(`/api/disclaimer/${encodeURIComponent(user!.username)}/supplement_reminders`);
      if (!res.ok) return { accepted: false };
      return res.json();
    },
  });

  const createStackMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      return apiRequest("POST", "/api/stacks", { ...data, userId: user!.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stacks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
      setAddStackOpen(false);
      toast({ title: "Stack created" });
    },
  });

  const updateStackMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; name?: string; description?: string }) => {
      return apiRequest("PATCH", `/api/stacks/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stacks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
      setEditStackOpen(false);
      setEditingStack(null);
      toast({ title: "Stack updated" });
    },
  });

  const deleteStackMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/stacks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stacks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
      toast({ title: "Stack deleted" });
    },
  });

  const acceptDisclaimerMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/disclaimer", { 
        userId: user!.id, 
        disclaimerType: "supplement_reminders" 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disclaimer"] });
      setDisclaimerOpen(false);
      if (pendingReminderStackId) {
        setReminderStackId(pendingReminderStackId);
        setReminderOpen(true);
        setPendingReminderStackId(null);
      }
    },
  });

  const handleOpenReminders = (stackId: number) => {
    if (!disclaimerAccepted?.accepted) {
      setPendingReminderStackId(stackId);
      setDisclaimerOpen(true);
    } else {
      setReminderStackId(stackId);
      setReminderOpen(true);
    }
  };

  if (userLoading) {
    return (
      <Layout>
        <Skeleton className="h-[200px] w-full rounded-xl" />
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between pb-4 border-b">
          <div>
            <h1 className="text-2xl font-display font-bold">Supplement Stacks</h1>
            <p className="text-muted-foreground">Group supplements and set reminders</p>
          </div>
          <Dialog open={addStackOpen} onOpenChange={setAddStackOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-stack">
                <Plus className="mr-2 h-4 w-4" /> New Stack
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Stack</DialogTitle>
                <DialogDescription>Group your supplements together for easy tracking</DialogDescription>
              </DialogHeader>
              <StackForm
                onSubmit={(data) => createStackMutation.mutate(data)}
                isPending={createStackMutation.isPending}
                submitLabel="Create Stack"
              />
            </DialogContent>
          </Dialog>
        </div>

        {supplements.length === 0 && (
          <Card className="border-amber-500/50 bg-amber-500/5">
            <CardContent className="flex items-start gap-3 pt-4">
              <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-amber-700 dark:text-amber-400">No Supplements Added</p>
                <p className="text-muted-foreground">
                  Add supplements on the Supplements page before creating stacks.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Your Stacks</CardTitle>
            <CardDescription>
              {stacks.length === 0
                ? "No stacks created yet. Create your first stack to organize supplements."
                : `${stacks.length} stack${stacks.length === 1 ? '' : 's'}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stacksLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : stacks.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
                <Layers className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No stacks yet</p>
                <p className="text-sm">Click "New Stack" to get started</p>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {stacks.map((stack) => (
                    <StackCard
                      key={stack.id}
                      stack={stack}
                      supplements={supplements}
                      onEdit={() => {
                        setEditingStack(stack);
                        setEditStackOpen(true);
                      }}
                      onDelete={() => deleteStackMutation.mutate(stack.id)}
                      onManageSupplements={() => {
                        setManagingStackId(stack.id);
                        setManageSupplementsOpen(true);
                      }}
                      onManageReminders={() => handleOpenReminders(stack.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={editStackOpen} onOpenChange={(open) => {
          setEditStackOpen(open);
          if (!open) setEditingStack(null);
        }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Stack</DialogTitle>
            </DialogHeader>
            {editingStack && (
              <StackForm
                initialName={editingStack.name}
                initialDescription={editingStack.description || ""}
                onSubmit={(data) => updateStackMutation.mutate({ id: editingStack.id, ...data })}
                isPending={updateStackMutation.isPending}
                submitLabel="Save Changes"
              />
            )}
          </DialogContent>
        </Dialog>

        <ManageSupplementsDialog
          open={manageSupplementsOpen}
          onOpenChange={setManageSupplementsOpen}
          stackId={managingStackId}
          supplements={supplements}
        />

        <RemindersDialog
          open={reminderOpen}
          onOpenChange={setReminderOpen}
          stackId={reminderStackId}
          stackName={stacks.find(s => s.id === reminderStackId)?.name}
        />

        <Dialog open={disclaimerOpen} onOpenChange={setDisclaimerOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                Reminder Disclaimer
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <p className="text-sm text-muted-foreground">
                Before enabling supplement reminders, please read and accept the following:
              </p>
              <div className="p-4 bg-secondary/50 rounded-lg text-sm space-y-2">
                <p>
                  <strong>This is a personal tracking tool only.</strong> The reminders feature is 
                  designed to help you remember your personal supplement schedule.
                </p>
                <p>
                  This app does not provide medical advice, dosage recommendations, 
                  or health claims. Supplement timing and combinations shown are based solely 
                  on your own inputs.
                </p>
                <p>
                  Always consult a healthcare professional before starting, stopping, or 
                  modifying any supplement regimen.
                </p>
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setDisclaimerOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => acceptDisclaimerMutation.mutate()}
                disabled={acceptDisclaimerMutation.isPending}
                data-testid="button-accept-disclaimer"
              >
                {acceptDisclaimerMutation.isPending ? "Accepting..." : "I Understand & Accept"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}

function StackForm({
  initialName = "",
  initialDescription = "",
  onSubmit,
  isPending,
  submitLabel,
}: {
  initialName?: string;
  initialDescription?: string;
  onSubmit: (data: { name: string; description?: string }) => void;
  isPending: boolean;
  submitLabel: string;
}) {
  const [name, setName] = useState(initialName);
  const [description, setDescription] = useState(initialDescription);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({ name: name.trim(), description: description.trim() || undefined });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="stack-name">Stack Name *</Label>
        <Input
          id="stack-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g., Morning Routine"
          required
          data-testid="input-stack-name"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="stack-desc">Description (optional)</Label>
        <Textarea
          id="stack-desc"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of this stack..."
          className="resize-none"
          data-testid="input-stack-description"
        />
      </div>
      <DialogFooter>
        <Button type="submit" disabled={isPending || !name.trim()} data-testid="button-save-stack">
          {isPending ? "Saving..." : submitLabel}
        </Button>
      </DialogFooter>
    </form>
  );
}

function StackCard({
  stack,
  supplements,
  onEdit,
  onDelete,
  onManageSupplements,
  onManageReminders,
}: {
  stack: SupplementStack;
  supplements: Supplement[];
  onEdit: () => void;
  onDelete: () => void;
  onManageSupplements: () => void;
  onManageReminders: () => void;
}) {
  const { data: stackSupplements = [] } = useQuery<StackSupplement[]>({
    queryKey: ["/api/stacks", stack.id, "supplements"],
  });

  const { data: reminders = [] } = useQuery<StackReminder[]>({
    queryKey: ["/api/stacks", stack.id, "reminders"],
  });

  const suppNames = stackSupplements
    .map(ss => supplements.find(s => s.id === ss.supplementId)?.name)
    .filter(Boolean);

  const activeReminders = reminders.filter(r => r.enabled);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="p-4 rounded-lg border bg-secondary/30 group"
      data-testid={`stack-item-${stack.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-medium">{stack.name}</h3>
          {stack.description && (
            <p className="text-sm text-muted-foreground">{stack.description}</p>
          )}
        </div>
        <div className="flex gap-1">
          <Button size="icon" variant="ghost" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive" onClick={onDelete}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-3">
        {suppNames.length === 0 ? (
          <span className="text-xs text-muted-foreground italic">No supplements assigned</span>
        ) : (
          suppNames.map((name, i) => (
            <Badge key={i} variant="secondary" className="text-xs">{name}</Badge>
          ))
        )}
      </div>

      <div className="flex items-center gap-2 pt-2 border-t">
        <Button size="sm" variant="outline" onClick={onManageSupplements} data-testid={`button-manage-supps-${stack.id}`}>
          <Plus className="mr-1 h-3 w-3" /> Manage Supplements
        </Button>
        <Button size="sm" variant="outline" onClick={onManageReminders} data-testid={`button-manage-reminders-${stack.id}`}>
          <Bell className="mr-1 h-3 w-3" /> 
          Reminders {activeReminders.length > 0 && <Badge variant="secondary" className="ml-1 text-[10px]">{activeReminders.length}</Badge>}
        </Button>
      </div>
    </motion.div>
  );
}

function ManageSupplementsDialog({
  open,
  onOpenChange,
  stackId,
  supplements,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  stackId: number | null;
  supplements: Supplement[];
}) {
  const { data: stackSupplements = [], refetch } = useQuery<StackSupplement[]>({
    queryKey: ["/api/stacks", stackId, "supplements"],
    enabled: !!stackId,
  });

  const addMutation = useMutation({
    mutationFn: async (supplementId: number) => {
      return apiRequest("POST", `/api/stacks/${stackId}/supplements`, { supplementId });
    },
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/stacks", stackId, "supplements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (supplementId: number) => {
      return apiRequest("DELETE", `/api/stacks/${stackId}/supplements/${supplementId}`);
    },
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/stacks", stackId, "supplements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
    },
  });

  const assignedIds = new Set(stackSupplements.map(ss => ss.supplementId));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Manage Supplements in Stack</DialogTitle>
          <DialogDescription>Select which supplements belong to this stack</DialogDescription>
        </DialogHeader>
        <div className="space-y-2 max-h-[300px] overflow-y-auto py-2">
          {supplements.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              No supplements available. Add supplements first.
            </p>
          ) : (
            supplements.map((supp) => {
              const isAssigned = assignedIds.has(supp.id);
              return (
                <div
                  key={supp.id}
                  className="flex items-center justify-between p-3 rounded-lg border hover-elevate"
                >
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={isAssigned}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          addMutation.mutate(supp.id);
                        } else {
                          removeMutation.mutate(supp.id);
                        }
                      }}
                      data-testid={`checkbox-supp-${supp.id}`}
                    />
                    <div>
                      <p className="font-medium text-sm">{supp.name}</p>
                      {supp.brand && <p className="text-xs text-muted-foreground">{supp.brand}</p>}
                    </div>
                  </div>
                  {supp.form && <Badge variant="outline" className="text-[10px] capitalize">{supp.form}</Badge>}
                </div>
              );
            })
          )}
        </div>
        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RemindersDialog({
  open,
  onOpenChange,
  stackId,
  stackName,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  stackId: number | null;
  stackName?: string;
}) {
  const { toast } = useToast();
  const [addingReminder, setAddingReminder] = useState(false);
  const [newTime, setNewTime] = useState("08:00");
  const [newDays, setNewDays] = useState<string[]>(["monday", "tuesday", "wednesday", "thursday", "friday"]);
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission | null>(
    typeof Notification !== "undefined" ? Notification.permission : null
  );

  const handleEnableNotifications = async () => {
    const result = await requestNotificationPermission();
    setNotificationStatus(result);
    if (result === "granted") {
      toast({ title: "Notifications enabled", description: "You'll receive browser notifications for reminders" });
    } else if (result === "denied") {
      toast({ title: "Notifications blocked", description: "Please enable notifications in your browser settings", variant: "destructive" });
    } else {
      toast({ title: "Notifications unavailable", description: "Your browser may not support notifications" });
    }
  };

  const handleTestReminder = () => {
    const name = stackName || "Test";
    triggerReminderNotification(name, toast);
  };

  const { data: reminders = [], refetch } = useQuery<StackReminder[]>({
    queryKey: ["/api/stacks", stackId, "reminders"],
    enabled: !!stackId,
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/reminders", {
        stackId,
        time: newTime,
        daysOfWeek: newDays,
        enabled: true,
      });
    },
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
      setAddingReminder(false);
      setNewTime("08:00");
      setNewDays(["monday", "tuesday", "wednesday", "thursday", "friday"]);
      toast({ title: "Reminder added" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number; enabled?: boolean; time?: string; daysOfWeek?: string[] }) => {
      return apiRequest("PATCH", `/api/reminders/${id}`, data);
    },
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/reminders/${id}`);
    },
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/stacks/scheduled"], exact: false });
      toast({ title: "Reminder deleted" });
    },
  });

  const toggleDay = (day: string) => {
    setNewDays(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Stack Reminders</DialogTitle>
          <DialogDescription>Set up reminders for when to take this stack</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {reminders.length === 0 && !addingReminder && (
            <p className="text-sm text-muted-foreground text-center py-4">
              No reminders set. Add a reminder to get notified.
            </p>
          )}

          {reminders.map((reminder) => {
            const days = JSON.parse(reminder.daysOfWeek) as string[];
            return (
              <div key={reminder.id} className="p-3 rounded-lg border space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{reminder.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={reminder.enabled}
                      onCheckedChange={(enabled) => updateMutation.mutate({ id: reminder.id, enabled })}
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => deleteMutation.mutate(reminder.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {DAYS_OF_WEEK.map(({ key, label }) => (
                    <Badge
                      key={key}
                      variant={days.includes(key) ? "default" : "outline"}
                      className="text-[10px]"
                    >
                      {label}
                    </Badge>
                  ))}
                </div>
              </div>
            );
          })}

          {addingReminder && (
            <div className="p-3 rounded-lg border border-primary/50 space-y-3">
              <div className="space-y-2">
                <Label>Time</Label>
                <Input
                  type="time"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  data-testid="input-reminder-time"
                />
              </div>
              <div className="space-y-2">
                <Label>Days</Label>
                <div className="flex flex-wrap gap-1">
                  {DAYS_OF_WEEK.map(({ key, label }) => (
                    <Badge
                      key={key}
                      variant={newDays.includes(key) ? "default" : "outline"}
                      className="cursor-pointer text-xs"
                      onClick={() => toggleDay(key)}
                    >
                      {label}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => createMutation.mutate()}
                  disabled={createMutation.isPending || newDays.length === 0}
                  data-testid="button-save-reminder"
                >
                  <Check className="mr-1 h-3 w-3" /> Save
                </Button>
                <Button size="sm" variant="outline" onClick={() => setAddingReminder(false)}>
                  <X className="mr-1 h-3 w-3" /> Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        <div className="text-xs text-muted-foreground text-center px-2 py-2 border-t bg-secondary/30 rounded">
          Reminders trigger while the app is open (MVP). Enable browser notifications for alerts even when minimized.
        </div>

        <DialogFooter className="flex-wrap gap-2">
          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleEnableNotifications}
              disabled={notificationStatus === "granted"}
              data-testid="button-enable-notifications"
            >
              <BellRing className="mr-1 h-3 w-3" />
              {notificationStatus === "granted" ? "Notifications On" : "Enable Notifications"}
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleTestReminder}
              data-testid="button-test-reminder"
            >
              <Volume2 className="mr-1 h-3 w-3" /> Test Reminder
            </Button>
          </div>
          <div className="flex gap-2 ml-auto">
            {!addingReminder && (
              <Button variant="outline" onClick={() => setAddingReminder(true)} data-testid="button-add-reminder">
                <Plus className="mr-2 h-4 w-4" /> Add Reminder
              </Button>
            )}
            <Button onClick={() => onOpenChange(false)}>Done</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
