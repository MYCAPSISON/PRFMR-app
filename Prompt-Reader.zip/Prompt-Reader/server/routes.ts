import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import ingredients from "../data/ingredients.json";

import { getMicronutrientValue } from "@shared/utils";

function calculateTargets(data: any) {
    const { gender, weight, height, age, activityLevel } = data;
    
    // 1. BMR (Mifflin-St Jeor)
    let bmr = (10 * weight) + (6.25 * height) - (5 * age);
    if (gender === 'male') {
        bmr += 5;
    } else {
        bmr -= 161;
    }

    // 2. TDEE
    const multipliers: Record<string, number> = {
        sedentary: 1.2,
        light: 1.375,
        moderate: 1.55,
        active: 1.725,
        very_active: 1.9
    };
    const tdee = bmr * (multipliers[activityLevel] || 1.2);

    // 3. Deficit (Conservative ~500kcal)
    const targetCalories = Math.round(tdee - 500);

    // 4. Macros
    // Protein: 2g per kg
    const targetProtein = Math.round(weight * 2.0); // 4 kcal/g
    
    // Fat: 0.8g per kg min, let's say 30% of remaining or fixed 0.9g/kg
    const targetFat = Math.round(weight * 0.9); // 9 kcal/g

    // Carbs: Remainder
    const proteinCals = targetProtein * 4;
    const fatCals = targetFat * 9;
    const remainingCals = targetCalories - proteinCals - fatCals;
    const targetCarbs = Math.max(0, Math.round(remainingCals / 4));

    return {
        targetCalories,
        targetProtein,
        targetFat,
        targetCarbs
    };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get("/api/food/barcode/:code", async (req, res) => {
    try {
      const { code } = req.params;
      const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${code}.json`);
      if (!response.ok) {
        return res.status(404).json({ found: false, message: "Product not found" });
      }
      const data = await response.json();
      
      const found = data.product && data.status !== "unknown";
      if (!found) {
        return res.status(404).json({ found: false, message: "Product not found" });
      }

      const p = data.product;
      const n = p.nutriments || {};

      const name = p.product_name || p.product_name_en || p.generic_name || p.name_en || "Unknown product";
      const image_url = p.image_front_url || p.image_url || p.selected_images?.front?.display?.en || null;
      
      let kcal = n["energy-kcal_100g"];
      let kcalSource = "kcal_100g";
      if (kcal === undefined && n["energy_100g"] !== undefined) {
        kcal = n["energy_100g"] / 4.184;
        kcalSource = "kJ conversion";
      }

      console.log(`[Barcode Debug] code: ${code}, status: ${data.status}, name: ${name}, kcalSource: ${kcalSource}`);

      res.json({
        found: true,
        name,
        image_url,
        calories_kcal_100g: Math.round(kcal || 0),
        protein_g_100g: n.proteins_100g || 0,
        carbs_g_100g: n.carbohydrates_100g || 0,
        fat_g_100g: n.fat_100g || 0,
        fibre_g_100g: n.fiber_100g || n.fibre_100g || 0,
      });
    } catch (error) {
      console.error("Barcode lookup error:", error);
      res.status(500).json({ found: false, message: "Error looking up barcode" });
    }
  });

  app.post(api.user.create.path, async (req, res) => {
      const { username } = api.user.create.input.parse(req.body);
      let user = await storage.getUser(username);
      if (!user) {
          user = await storage.createUser({ username });
      }
      res.status(201).json(user);
  });

  app.get(api.user.get.path, async (req, res) => {
      const user = await storage.getUser(req.params.username);
      if (!user) return res.status(404).json({ message: "User not found" });
      res.json(user);
  });

  app.post(api.user.onboard.path, async (req, res) => {
      const { username } = req.params;
      const data = api.user.onboard.input.parse(req.body);
      
      const targets = calculateTargets({
          gender: data.gender,
          weight: data.currentWeight,
          height: data.height,
          age: data.age,
          activityLevel: data.activityLevel
      });

      const updatedUser = await storage.updateUser(username, {
          ...data,
          ...targets
      });
      
      res.json(updatedUser);
  });

  app.get(api.logs.list.path, async (req, res) => {
      const user = await storage.getUser(req.params.username);
      if (!user) return res.status(404).json({ message: "User not found" });
      const logs = await storage.getLogs(user.id);
      res.json(logs);
  });

  app.post(api.logs.create.path, async (req, res) => {
      const data = api.logs.create.input.parse(req.body);
      const log = await storage.createLog(data);
      res.status(201).json(log);
  });

  app.patch(api.logs.update.path, async (req, res) => {
      const id = parseInt(req.params.id);
      const data = api.logs.update.input.parse(req.body);
      const log = await storage.updateLog(id, data);
      res.json(log);
  });

  app.get(api.food.list.path, async (req, res) => {
    const { username, date } = req.params;
    const user = await storage.getUser(username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const entries = await storage.getFoodEntries(user.id, date);
    res.json(entries);
  });

  app.get("/api/food-entries/range", async (req, res) => {
    const { username, start, end } = req.query;
    if (!username || !start || !end) {
      return res.status(400).json({ message: "Missing required parameters" });
    }
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    if (start > end) {
      return res.status(400).json({ message: "Start date must be before or equal to end date" });
    }

    // Since we're using MemStorage, we need to add this method or filter manually
    // Adding to IStorage first
    const entries = await (storage as any).getFoodEntriesRange(user.id, start as string, end as string);
    
    // Normalize dates to yyyy-MM-dd format to ensure consistent client-side comparison
    const normalizedEntries = entries.map((entry: any) => ({
      ...entry,
      date: typeof entry.date === 'string' 
        ? entry.date.includes('T') ? entry.date.split('T')[0] : entry.date
        : entry.date instanceof Date 
          ? entry.date.toISOString().split('T')[0] 
          : entry.date
    }));
    
    res.set("Cache-Control", "no-store");
    res.json(normalizedEntries);
  });

  app.post(api.food.create.path, async (req, res) => {
    const data = api.food.create.input.parse(req.body);
    const entry = await storage.createFoodEntry(data);
    res.status(201).json(entry);
  });

  app.patch("/api/food/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const entry = await storage.updateFoodEntry(id, req.body);
      res.json(entry);
    } catch (err) {
      res.status(404).json({ message: "Food entry not found" });
    }
  });

  app.delete(api.food.delete.path, async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteFoodEntry(id);
    res.status(204).end();
  });

  app.get("/api/weights/range", async (req, res) => {
    const { username, start, end } = req.query;
    if (!username || !start || !end) {
      return res.status(400).json({ message: "Missing required parameters" });
    }
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    if (start > end) {
      return res.status(400).json({ message: "Start date must be before or equal to end date" });
    }

    const weights = await storage.getWeightsRange(user.id, start as string, end as string);
    res.set("Cache-Control", "no-store");
    res.json(weights);
  });

  app.post("/api/weights", async (req, res) => {
    const { userId, date, weight } = req.body;
    if (!userId || !date || weight === undefined) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    const entry = await storage.upsertWeight({ userId, date, weight });
    res.status(201).json(entry);
  });

  app.delete("/api/weights/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteWeight(id);
    res.status(204).end();
  });

  app.get("/api/ingredients", async (_req, res) => {
    res.json(ingredients);
  });

  // ========== SCHEDULED STACKS API ==========
  
  // Helper to get weekday key from a date string
  function getWeekdayFromDate(dateStr: string): string {
    const date = new Date(dateStr + "T12:00:00Z"); // Use noon to avoid timezone issues
    const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    return days[date.getUTCDay()];
  }
  
  // Helper to safely parse daysOfWeek (handles string or array)
  function parseDaysOfWeek(daysOfWeek: string | string[]): string[] {
    if (Array.isArray(daysOfWeek)) return daysOfWeek.map(d => d.toLowerCase());
    try {
      const parsed = JSON.parse(daysOfWeek);
      if (Array.isArray(parsed)) return parsed.map((d: string) => d.toLowerCase());
      return [];
    } catch {
      return [];
    }
  }
  
  // Get scheduled stacks for a specific date - returns FLAT slots for proper duplicate handling
  app.get("/api/stacks/scheduled", async (req, res) => {
    const { username, date } = req.query;
    
    if (!username || !date) {
      return res.status(400).json({ message: "username and date are required" });
    }
    
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const weekday = getWeekdayFromDate(date as string);
    
    // Get all user data
    const stacks = await storage.getStacks(user.id);
    const allReminders = await storage.getAllRemindersForUser(user.id);
    const supplements = await storage.getSupplements(user.id);
    
    // Return flat slots: one row per (stackId, reminderId, supplementId)
    const slots: Array<{
      stackId: number;
      stackName: string;
      reminderId: number;
      time: string;
      supplementId: number;
      supplementName: string;
      doseAmount: number | null;
      doseUnit: string | null;
    }> = [];
    
    for (const stack of stacks) {
      // Get reminders for this stack that match the date
      const stackReminders = allReminders.filter(r => r.stackId === stack.id);
      const matchingReminders = stackReminders.filter(r => {
        if (!r.enabled) return false;
        const days = parseDaysOfWeek(r.daysOfWeek);
        return days.includes(weekday);
      });
      
      if (matchingReminders.length === 0) continue;
      
      // Get supplements for this stack
      const stackSupplementLinks = await storage.getStackSupplements(stack.id);
      const stackSupplements = stackSupplementLinks
        .map(link => supplements.find(s => s.id === link.supplementId))
        .filter((s): s is NonNullable<typeof s> => s !== undefined);
      
      // Create a slot for each reminder + supplement combination
      for (const reminder of matchingReminders) {
        for (const supp of stackSupplements) {
          slots.push({
            stackId: stack.id,
            stackName: stack.name,
            reminderId: reminder.id,
            time: reminder.time,
            supplementId: supp.id,
            supplementName: supp.name,
            doseAmount: supp.doseAmount,
            doseUnit: supp.doseUnit,
          });
        }
      }
    }
    
    // Sort by time, then stack name
    slots.sort((a, b) => a.time.localeCompare(b.time) || a.stackName.localeCompare(b.stackName));
    
    res.json(slots);
  });

  // ========== SUPPLEMENTS API ==========
  
  // Get all supplements for a user
  app.get("/api/supplements/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const supplements = await storage.getSupplements(user.id);
    res.json(supplements);
  });

  // Create a supplement
  app.post("/api/supplements", async (req, res) => {
    const { userId, name, brand, form, notes } = req.body;
    if (!userId || !name) {
      return res.status(400).json({ message: "userId and name are required" });
    }
    const supplement = await storage.createSupplement({ userId, name, brand, form, notes });
    res.status(201).json(supplement);
  });

  // Update a supplement
  app.patch("/api/supplements/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const supplement = await storage.updateSupplement(id, req.body);
      res.json(supplement);
    } catch (err) {
      res.status(404).json({ message: "Supplement not found" });
    }
  });

  // Delete a supplement
  app.delete("/api/supplements/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteSupplement(id);
    res.status(204).end();
  });

  // ========== STACKS API ==========
  
  // Get all stacks for a user
  app.get("/api/stacks/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const stacks = await storage.getStacks(user.id);
    res.json(stacks);
  });

  // Create a stack
  app.post("/api/stacks", async (req, res) => {
    const { userId, name, description } = req.body;
    if (!userId || !name) {
      return res.status(400).json({ message: "userId and name are required" });
    }
    const stack = await storage.createStack({ userId, name, description });
    res.status(201).json(stack);
  });

  // Update a stack
  app.patch("/api/stacks/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const stack = await storage.updateStack(id, req.body);
      res.json(stack);
    } catch (err) {
      res.status(404).json({ message: "Stack not found" });
    }
  });

  // Delete a stack
  app.delete("/api/stacks/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteStack(id);
    res.status(204).end();
  });

  // ========== STACK-SUPPLEMENTS API ==========
  
  // Get supplements in a stack
  app.get("/api/stacks/:stackId/supplements", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const stackSupplements = await storage.getStackSupplements(stackId);
    res.json(stackSupplements);
  });

  // Add a supplement to a stack
  app.post("/api/stacks/:stackId/supplements", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const { supplementId } = req.body;
    if (!supplementId) {
      return res.status(400).json({ message: "supplementId is required" });
    }
    const entry = await storage.addSupplementToStack({ stackId, supplementId });
    res.status(201).json(entry);
  });

  // Remove a supplement from a stack
  app.delete("/api/stacks/:stackId/supplements/:supplementId", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const supplementId = parseInt(req.params.supplementId);
    await storage.removeSupplementFromStack(stackId, supplementId);
    res.status(204).end();
  });

  // ========== REMINDERS API ==========
  
  // Get reminders for a stack
  app.get("/api/stacks/:stackId/reminders", async (req, res) => {
    const stackId = parseInt(req.params.stackId);
    const reminders = await storage.getStackReminders(stackId);
    res.json(reminders);
  });

  // Get all reminders for a user
  app.get("/api/reminders/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const reminders = await storage.getAllRemindersForUser(user.id);
    res.json(reminders);
  });

  // Get today's enabled reminders with stack names (for reminder engine)
  app.get("/api/reminders/today/:username", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const reminders = await storage.getTodaysRemindersForUser(user.id);
    // Parse daysOfWeek from JSON string to array for client convenience
    const parsed = reminders.map(r => ({
      ...r,
      daysOfWeek: typeof r.daysOfWeek === 'string' ? JSON.parse(r.daysOfWeek) : r.daysOfWeek
    }));
    res.json(parsed);
  });

  // Create a reminder (requires disclaimer acceptance)
  app.post("/api/reminders", async (req, res) => {
    const { stackId, time, daysOfWeek, enabled, userId } = req.body;
    if (!stackId || !time || !daysOfWeek) {
      return res.status(400).json({ message: "stackId, time, and daysOfWeek are required" });
    }
    
    // Verify stack exists and get userId if not provided
    const stack = await storage.getStack(stackId);
    if (!stack) {
      return res.status(404).json({ message: "Stack not found" });
    }
    
    // Check disclaimer acceptance
    const acceptance = await storage.getDisclaimerAcceptance(stack.userId, "supplement_reminders");
    if (!acceptance) {
      return res.status(403).json({ message: "Disclaimer must be accepted before creating reminders" });
    }
    
    const reminder = await storage.createReminder({ 
      stackId, 
      time, 
      daysOfWeek: JSON.stringify(daysOfWeek), 
      enabled: enabled ?? true 
    });
    res.status(201).json(reminder);
  });

  // Update a reminder
  app.patch("/api/reminders/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const updates = { ...req.body };
    if (updates.daysOfWeek && Array.isArray(updates.daysOfWeek)) {
      updates.daysOfWeek = JSON.stringify(updates.daysOfWeek);
    }
    try {
      const reminder = await storage.updateReminder(id, updates);
      res.json(reminder);
    } catch (err) {
      res.status(404).json({ message: "Reminder not found" });
    }
  });

  // Delete a reminder
  app.delete("/api/reminders/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteReminder(id);
    res.status(204).end();
  });

  // ========== SUPPLEMENT LOGS API ==========
  
  // Get supplement logs for a user on a specific date
  app.get("/api/supplement-logs/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const logs = await storage.getSupplementLogs(user.id, req.params.date);
    res.json(logs);
  });

  // Log a supplement as taken
  app.post("/api/supplement-logs", async (req, res) => {
    const { userId, supplementId, stackId, date, time, taken } = req.body;
    if (!userId || !supplementId || !date) {
      return res.status(400).json({ message: "userId, supplementId, and date are required" });
    }
    const log = await storage.createSupplementLog({ userId, supplementId, stackId, date, time, taken });
    res.status(201).json(log);
  });

  // Delete a supplement log
  app.delete("/api/supplement-logs/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteSupplementLog(id);
    res.status(204).end();
  });

  // ========== DISCLAIMER ACCEPTANCE API ==========
  
  // Check if user has accepted a disclaimer
  app.get("/api/disclaimer/:username/:type", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const acceptance = await storage.getDisclaimerAcceptance(user.id, req.params.type);
    res.json({ accepted: !!acceptance, acceptedAt: acceptance?.acceptedAt });
  });

  // Record disclaimer acceptance
  app.post("/api/disclaimer", async (req, res) => {
    const { userId, disclaimerType } = req.body;
    if (!userId || !disclaimerType) {
      return res.status(400).json({ message: "userId and disclaimerType are required" });
    }
    const acceptance = await storage.createDisclaimerAcceptance({
      userId,
      disclaimerType,
      acceptedAt: new Date().toISOString(),
    });
    res.status(201).json(acceptance);
  });

  // ========== SUPPLEMENT CATALOG API ==========
  
  // Search/list supplement catalog
  app.get("/api/supplement-catalog", async (req, res) => {
    const query = req.query.q as string | undefined;
    const catalog = await storage.getSupplementCatalog(query);
    res.json(catalog);
  });

  // Get single catalog item
  app.get("/api/supplement-catalog/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const item = await storage.getSupplementCatalogItem(id);
    if (!item) return res.status(404).json({ message: "Catalog item not found" });
    res.json(item);
  });

  // ========== SUPPLEMENT INTAKES API ==========
  
  // Get supplement intakes using query params (for dashboard) - returns slot keys
  app.get("/api/supplement-intakes", async (req, res) => {
    const { username, date } = req.query;
    if (!username || !date) {
      return res.status(400).json({ message: "username and date are required" });
    }
    const user = await storage.getUser(username as string);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakes(user.id, date as string);
    // Return slot keys (stackId-reminderId-supplementId) for taken supplements
    // Use actual IDs (not 0 fallback) to match dashboard keys
    const takenSlotKeys = intakes
      .filter(i => i.taken && i.stackId !== null && i.reminderId !== null)
      .map(i => `${i.stackId}-${i.reminderId}-${i.supplementId}`);
    res.json({ takenSlotKeys });
  });
  
  // Get supplement intakes for a user on a specific date
  app.get("/api/supplement-intakes/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakes(user.id, req.params.date);
    res.json(intakes);
  });

  // Get supplement intakes for a date range (for AMQS)
  app.get("/api/supplement-intakes/:username/:startDate/:endDate", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    const intakes = await storage.getSupplementIntakesRange(user.id, req.params.startDate, req.params.endDate);
    res.json(intakes);
  });

  // Log supplement intake (upsert per slot: stackId + reminderId + supplementId + date)
  app.post("/api/supplement-intakes", async (req, res) => {
    const { userId, supplementId, stackId, reminderId, date, taken } = req.body;
    if (!userId || !supplementId || !date) {
      return res.status(400).json({ message: "userId, supplementId, and date are required" });
    }
    
    // Normalize stackId and reminderId (convert undefined to null)
    const normalizedStackId = stackId ?? null;
    const normalizedReminderId = reminderId ?? null;
    
    // Check if intake already exists for this specific slot
    const existingIntakes = await storage.getSupplementIntakes(userId, date);
    const existing = existingIntakes.find(i => 
      i.supplementId === supplementId && 
      i.stackId === normalizedStackId && 
      i.reminderId === normalizedReminderId
    );
    
    if (taken === false) {
      // Delete the intake if it exists
      if (existing) {
        await storage.deleteSupplementIntake(existing.id);
      }
      return res.json({ deleted: true, supplementId, stackId: normalizedStackId, reminderId: normalizedReminderId, date });
    }
    
    // Upsert: update if exists, create if not
    if (existing) {
      const updated = await storage.updateSupplementIntake(existing.id, { 
        taken: true, 
        takenAt: new Date().toISOString() 
      });
      return res.json(updated);
    }
    
    const intake = await storage.createSupplementIntake({ 
      userId, 
      supplementId,
      stackId: normalizedStackId,
      reminderId: normalizedReminderId,
      date, 
      taken: true, 
      takenAt: new Date().toISOString() 
    });
    res.status(201).json(intake);
  });

  // Update supplement intake
  app.patch("/api/supplement-intakes/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const intake = await storage.updateSupplementIntake(id, req.body);
      res.json(intake);
    } catch (err) {
      res.status(404).json({ message: "Intake not found" });
    }
  });

  // Delete supplement intake
  app.delete("/api/supplement-intakes/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteSupplementIntake(id);
    res.status(204).end();
  });

  // ========== SUPPLEMENT MICRONUTRIENTS FOR AMQS ==========
  
  // Get daily supplement micronutrients contribution
  app.get("/api/supplement-micros/:username/:date", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const intakes = await storage.getSupplementIntakes(user.id, req.params.date);
    const supplements = await storage.getSupplements(user.id);
    const catalog = await storage.getSupplementCatalog();
    
    const microTotals: Record<string, number> = {};
    
    for (const intake of intakes) {
      if (!intake.taken) continue;
      
      const supplement = supplements.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      
      try {
        const microsPerUnit = JSON.parse(catalogItem.microsPerUnit) as Record<string, number>;
        for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
          const contribution = valuePerUnit * supplement.doseAmount;
          microTotals[key] = (microTotals[key] || 0) + contribution;
        }
      } catch (e) {
        // Invalid JSON, skip
      }
    }
    
    res.json(microTotals);
  });

  // Get supplement micronutrients for a date range (for weekly AMQS)
  app.get("/api/supplement-micros-range/:username/:startDate/:endDate", async (req, res) => {
    const user = await storage.getUser(req.params.username);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    const { startDate, endDate } = req.params;
    const intakes = await storage.getSupplementIntakesRange(user.id, startDate, endDate);
    const supplements = await storage.getSupplements(user.id);
    const catalog = await storage.getSupplementCatalog();
    
    // Group by date
    const microsByDate: Record<string, Record<string, number>> = {};
    
    for (const intake of intakes) {
      if (!intake.taken) continue;
      
      const supplement = supplements.find(s => s.id === intake.supplementId);
      if (!supplement || !supplement.catalogId || !supplement.doseAmount) continue;
      
      const catalogItem = catalog.find(c => c.id === supplement.catalogId);
      if (!catalogItem) continue;
      
      if (!microsByDate[intake.date]) {
        microsByDate[intake.date] = {};
      }
      
      try {
        const microsPerUnit = JSON.parse(catalogItem.microsPerUnit) as Record<string, number>;
        for (const [key, valuePerUnit] of Object.entries(microsPerUnit)) {
          const contribution = valuePerUnit * supplement.doseAmount;
          microsByDate[intake.date][key] = (microsByDate[intake.date][key] || 0) + contribution;
        }
      } catch (e) {
        // Invalid JSON, skip
      }
    }
    
    res.json(microsByDate);
  });

  return httpServer;
}
