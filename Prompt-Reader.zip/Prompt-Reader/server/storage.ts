import { 
  users, logs, foodEntries, weights, 
  supplements, supplementStacks, stackSupplements, stackReminders, supplementLogs, userDisclaimerAcceptance,
  supplementCatalog, supplementIntakes,
  type User, type InsertUser, type Log, type InsertLog, type FoodEntry, type InsertFoodEntry, type Weight, type InsertWeight,
  type Supplement, type InsertSupplement, type SupplementStack, type InsertSupplementStack,
  type StackSupplement, type InsertStackSupplement, type StackReminder, type InsertStackReminder,
  type SupplementLog, type InsertSupplementLog, type UserDisclaimerAcceptance, type InsertUserDisclaimerAcceptance,
  type SupplementCatalogItem, type InsertSupplementCatalogItem, type SupplementIntake, type InsertSupplementIntake
} from "@shared/schema";

export interface IStorage {
  getUser(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(username: string, user: Partial<InsertUser>): Promise<User>;
  getLogs(userId: number): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
  updateLog(id: number, log: Partial<InsertLog>): Promise<Log>;
  getFoodEntries(userId: number, date: string): Promise<FoodEntry[]>;
  getFoodEntriesRange(userId: number, startDate: string, endDate: string): Promise<FoodEntry[]>;
  createFoodEntry(entry: InsertFoodEntry): Promise<FoodEntry>;
  updateFoodEntry(id: number, entry: Partial<InsertFoodEntry>): Promise<FoodEntry>;
  deleteFoodEntry(id: number): Promise<void>;
  getWeightsRange(userId: number, startDate: string, endDate: string): Promise<Weight[]>;
  upsertWeight(entry: InsertWeight): Promise<Weight>;
  deleteWeight(id: number): Promise<void>;
  
  // Supplements
  getSupplements(userId: number): Promise<Supplement[]>;
  getSupplement(id: number): Promise<Supplement | undefined>;
  createSupplement(supplement: InsertSupplement): Promise<Supplement>;
  updateSupplement(id: number, supplement: Partial<InsertSupplement>): Promise<Supplement>;
  deleteSupplement(id: number): Promise<void>;
  
  // Stacks
  getStacks(userId: number): Promise<SupplementStack[]>;
  getStack(id: number): Promise<SupplementStack | undefined>;
  createStack(stack: InsertSupplementStack): Promise<SupplementStack>;
  updateStack(id: number, stack: Partial<InsertSupplementStack>): Promise<SupplementStack>;
  deleteStack(id: number): Promise<void>;
  
  // Stack-Supplement relationships
  getStackSupplements(stackId: number): Promise<StackSupplement[]>;
  addSupplementToStack(entry: InsertStackSupplement): Promise<StackSupplement>;
  removeSupplementFromStack(stackId: number, supplementId: number): Promise<void>;
  
  // Reminders
  getStackReminders(stackId: number): Promise<StackReminder[]>;
  getAllRemindersForUser(userId: number): Promise<StackReminder[]>;
  getTodaysRemindersForUser(userId: number): Promise<Array<StackReminder & { stackName: string }>>;
  createReminder(reminder: InsertStackReminder): Promise<StackReminder>;
  updateReminder(id: number, reminder: Partial<InsertStackReminder>): Promise<StackReminder>;
  deleteReminder(id: number): Promise<void>;
  
  // Supplement Logs
  getSupplementLogs(userId: number, date: string): Promise<SupplementLog[]>;
  createSupplementLog(log: InsertSupplementLog): Promise<SupplementLog>;
  deleteSupplementLog(id: number): Promise<void>;
  
  // Disclaimer acceptance
  getDisclaimerAcceptance(userId: number, type: string): Promise<UserDisclaimerAcceptance | undefined>;
  createDisclaimerAcceptance(acceptance: InsertUserDisclaimerAcceptance): Promise<UserDisclaimerAcceptance>;
  
  // Supplement Catalog
  getSupplementCatalog(query?: string): Promise<SupplementCatalogItem[]>;
  getSupplementCatalogItem(id: number): Promise<SupplementCatalogItem | undefined>;
  
  // Supplement Intakes
  getSupplementIntakes(userId: number, date: string): Promise<SupplementIntake[]>;
  getSupplementIntakesRange(userId: number, startDate: string, endDate: string): Promise<SupplementIntake[]>;
  createSupplementIntake(intake: InsertSupplementIntake): Promise<SupplementIntake>;
  updateSupplementIntake(id: number, intake: Partial<InsertSupplementIntake>): Promise<SupplementIntake>;
  deleteSupplementIntake(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private logs: Map<number, Log>;
  private foodEntries: Map<number, FoodEntry>;
  private weights: Map<number, Weight>;
  private supplementsMap: Map<number, Supplement>;
  private stacksMap: Map<number, SupplementStack>;
  private stackSupplementsMap: Map<number, StackSupplement>;
  private remindersMap: Map<number, StackReminder>;
  private supplementLogsMap: Map<number, SupplementLog>;
  private disclaimerAcceptancesMap: Map<number, UserDisclaimerAcceptance>;
  private supplementCatalogMap: Map<number, SupplementCatalogItem>;
  private supplementIntakesMap: Map<number, SupplementIntake>;
  
  private userIdCounter: number;
  private logIdCounter: number;
  private foodIdCounter: number;
  private weightIdCounter: number;
  private supplementIdCounter: number;
  private stackIdCounter: number;
  private stackSupplementIdCounter: number;
  private reminderIdCounter: number;
  private supplementLogIdCounter: number;
  private disclaimerIdCounter: number;
  private supplementIntakeIdCounter: number;

  constructor() {
    this.users = new Map();
    this.logs = new Map();
    this.foodEntries = new Map();
    this.weights = new Map();
    this.supplementsMap = new Map();
    this.stacksMap = new Map();
    this.stackSupplementsMap = new Map();
    this.remindersMap = new Map();
    this.supplementLogsMap = new Map();
    this.disclaimerAcceptancesMap = new Map();
    this.supplementCatalogMap = new Map();
    this.supplementIntakesMap = new Map();
    
    this.userIdCounter = 1;
    this.logIdCounter = 1;
    this.foodIdCounter = 1;
    this.weightIdCounter = 1;
    this.supplementIdCounter = 1;
    this.stackIdCounter = 1;
    this.stackSupplementIdCounter = 1;
    this.reminderIdCounter = 1;
    this.supplementLogIdCounter = 1;
    this.disclaimerIdCounter = 1;
    this.supplementIntakeIdCounter = 1;
    
    this.seedSupplementCatalog();
  }
  
  private seedSupplementCatalog() {
    const catalogItems: Omit<SupplementCatalogItem, "id">[] = [
      { name: "Vitamin D3", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ vitamin_d_ug: 1 }), notes: "Also available in IU (1 IU = 0.025 mcg)" },
      { name: "Vitamin D3 (IU)", defaultUnit: "IU", microsPerUnit: JSON.stringify({ vitamin_d_ug: 0.025 }), notes: "1 IU = 0.025 mcg" },
      { name: "Magnesium Glycinate", defaultUnit: "mg", microsPerUnit: JSON.stringify({ magnesium_mg: 1 }), notes: "Highly bioavailable form" },
      { name: "Magnesium Citrate", defaultUnit: "mg", microsPerUnit: JSON.stringify({ magnesium_mg: 1 }), notes: null },
      { name: "Zinc", defaultUnit: "mg", microsPerUnit: JSON.stringify({ zinc_mg: 1 }), notes: null },
      { name: "Iron", defaultUnit: "mg", microsPerUnit: JSON.stringify({ iron_mg: 1 }), notes: "Best absorbed with vitamin C" },
      { name: "Vitamin B12", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ vitamin_b12_ug: 1 }), notes: "Essential for vegans" },
      { name: "Folate (5-MTHF)", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ folate_ug: 1 }), notes: "Active form of folate" },
      { name: "Folic Acid", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ folate_ug: 1 }), notes: "Synthetic form" },
      { name: "Calcium", defaultUnit: "mg", microsPerUnit: JSON.stringify({ calcium_mg: 1 }), notes: "Take separately from iron/zinc" },
      { name: "Iodine", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ iodine_ug: 1 }), notes: null },
      { name: "Selenium", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ selenium_ug: 1 }), notes: null },
      { name: "Vitamin C", defaultUnit: "mg", microsPerUnit: JSON.stringify({ vitamin_c_mg: 1 }), notes: "Enhances iron absorption" },
      { name: "Vitamin A", defaultUnit: "mcg", microsPerUnit: JSON.stringify({ vitamin_a_ug: 1 }), notes: "RAE (Retinol Activity Equivalents)" },
      { name: "Potassium", defaultUnit: "mg", microsPerUnit: JSON.stringify({ potassium_mg: 1 }), notes: null },
      { name: "Omega-3 (EPA/DHA)", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Combined EPA+DHA content" },
      { name: "Fish Oil", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Check EPA/DHA content on label" },
      { name: "Creatine Monohydrate", defaultUnit: "g", microsPerUnit: JSON.stringify({}), notes: "Standard dose 3-5g daily" },
      { name: "Vitamin K2 (MK-7)", defaultUnit: "mcg", microsPerUnit: JSON.stringify({}), notes: "Synergistic with Vitamin D" },
      { name: "Vitamin E", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: null },
      { name: "Biotin", defaultUnit: "mcg", microsPerUnit: JSON.stringify({}), notes: "B7 - Hair, skin, nails" },
      { name: "CoQ10", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Ubiquinone or Ubiquinol" },
      { name: "Ashwagandha", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Adaptogen" },
      { name: "Turmeric/Curcumin", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Take with black pepper for absorption" },
      { name: "Probiotics", defaultUnit: "CFU", microsPerUnit: JSON.stringify({}), notes: "Colony Forming Units" },
      { name: "Vitamin B Complex", defaultUnit: "serving", microsPerUnit: JSON.stringify({ vitamin_b12_ug: 2.4, folate_ug: 400 }), notes: "Contains multiple B vitamins" },
      { name: "Multivitamin", defaultUnit: "serving", microsPerUnit: JSON.stringify({ vitamin_d_ug: 10, vitamin_c_mg: 80, iron_mg: 14, zinc_mg: 10, selenium_ug: 55, vitamin_b12_ug: 2.5, folate_ug: 200, vitamin_a_ug: 800, calcium_mg: 200, magnesium_mg: 100, iodine_ug: 150 }), notes: "Amounts vary by brand - update based on your label" },
      { name: "Electrolytes", defaultUnit: "serving", microsPerUnit: JSON.stringify({ potassium_mg: 200, magnesium_mg: 60 }), notes: "Amounts vary by product" },
      { name: "Collagen Peptides", defaultUnit: "g", microsPerUnit: JSON.stringify({}), notes: "Protein supplement" },
      { name: "L-Theanine", defaultUnit: "mg", microsPerUnit: JSON.stringify({}), notes: "Often paired with caffeine" },
    ];
    
    let id = 1;
    for (const item of catalogItems) {
      this.supplementCatalogMap.set(id, { ...item, id });
      id++;
    }
  }

  async getUser(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, age: null, gender: null, height: null, currentWeight: null, activityLevel: null, goal: null, experienceLevel: null, targetCalories: null, targetProtein: null, targetCarbs: null, targetFat: null };
    this.users.set(insertUser.username, user);
    return user;
  }

  async updateUser(username: string, updates: Partial<InsertUser>): Promise<User> {
    const user = await this.getUser(username);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...updates };
    this.users.set(username, updatedUser);
    return updatedUser;
  }

  async getLogs(userId: number): Promise<Log[]> {
    return Array.from(this.logs.values()).filter(log => log.userId === userId);
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const id = this.logIdCounter++;
    const log: Log = { 
      ...insertLog, 
      id, 
      weight: insertLog.weight ?? null,
      calories: insertLog.calories ?? 0, 
      protein: insertLog.protein ?? 0, 
      carbs: insertLog.carbs ?? 0, 
      fat: insertLog.fat ?? 0, 
      fibre: insertLog.fibre ?? 0 
    };
    this.logs.set(id, log);
    return log;
  }

  async updateLog(id: number, updates: Partial<InsertLog>): Promise<Log> {
    const log = this.logs.get(id);
    if (!log) throw new Error("Log not found");
    
    const updatedLog = { ...log, ...updates } as Log;
    this.logs.set(id, updatedLog);
    return updatedLog;
  }

  async getFoodEntries(userId: number, date: string): Promise<FoodEntry[]> {
    return Array.from(this.foodEntries.values()).filter(entry => entry.userId === userId && entry.date === date);
  }

  async getFoodEntriesRange(userId: number, startDate: string, endDate: string): Promise<FoodEntry[]> {
    return Array.from(this.foodEntries.values())
      .filter(entry => entry.userId === userId && entry.date >= startDate && entry.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async createFoodEntry(insertEntry: InsertFoodEntry): Promise<FoodEntry> {
    const id = this.foodIdCounter++;
    const entry: FoodEntry = { 
      ...insertEntry, 
      id,
      fibre: insertEntry.fibre ?? 0,
      grams: insertEntry.grams ?? 100,
      meal: insertEntry.meal ?? "lunch",
      snackIndex: insertEntry.snackIndex ?? null
    };
    this.foodEntries.set(id, entry);
    return entry;
  }

  async updateFoodEntry(id: number, updates: Partial<InsertFoodEntry>): Promise<FoodEntry> {
    const entry = this.foodEntries.get(id);
    if (!entry) throw new Error("Food entry not found");
    const updatedEntry = { ...entry, ...updates } as FoodEntry;
    this.foodEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteFoodEntry(id: number): Promise<void> {
    this.foodEntries.delete(id);
  }

  async getWeightsRange(userId: number, startDate: string, endDate: string): Promise<Weight[]> {
    return Array.from(this.weights.values())
      .filter(w => w.userId === userId && w.date >= startDate && w.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async upsertWeight(entry: InsertWeight): Promise<Weight> {
    const existing = Array.from(this.weights.values()).find(
      w => w.userId === entry.userId && w.date === entry.date
    );
    if (existing) {
      const updated: Weight = { ...existing, weight: entry.weight };
      this.weights.set(existing.id, updated);
      return updated;
    }
    const id = this.weightIdCounter++;
    const newWeight: Weight = { ...entry, id };
    this.weights.set(id, newWeight);
    return newWeight;
  }

  async deleteWeight(id: number): Promise<void> {
    this.weights.delete(id);
  }

  // Supplements
  async getSupplements(userId: number): Promise<Supplement[]> {
    return Array.from(this.supplementsMap.values()).filter(s => s.userId === userId);
  }

  async getSupplement(id: number): Promise<Supplement | undefined> {
    return this.supplementsMap.get(id);
  }

  async createSupplement(insert: InsertSupplement): Promise<Supplement> {
    const id = this.supplementIdCounter++;
    const supplement: Supplement = { 
      ...insert, 
      id, 
      brand: insert.brand ?? null,
      form: insert.form ?? null,
      notes: insert.notes ?? null,
      catalogId: insert.catalogId ?? null,
      doseAmount: insert.doseAmount ?? null,
      doseUnit: insert.doseUnit ?? null
    };
    this.supplementsMap.set(id, supplement);
    return supplement;
  }

  async updateSupplement(id: number, updates: Partial<InsertSupplement>): Promise<Supplement> {
    const supplement = this.supplementsMap.get(id);
    if (!supplement) throw new Error("Supplement not found");
    const updated = { ...supplement, ...updates } as Supplement;
    this.supplementsMap.set(id, updated);
    return updated;
  }

  async deleteSupplement(id: number): Promise<void> {
    this.supplementsMap.delete(id);
    // Also remove from any stacks
    Array.from(this.stackSupplementsMap.entries()).forEach(([key, ss]) => {
      if (ss.supplementId === id) this.stackSupplementsMap.delete(key);
    });
  }

  // Stacks
  async getStacks(userId: number): Promise<SupplementStack[]> {
    return Array.from(this.stacksMap.values()).filter(s => s.userId === userId);
  }

  async getStack(id: number): Promise<SupplementStack | undefined> {
    return this.stacksMap.get(id);
  }

  async createStack(insert: InsertSupplementStack): Promise<SupplementStack> {
    const id = this.stackIdCounter++;
    const stack: SupplementStack = { 
      ...insert, 
      id, 
      description: insert.description ?? null
    };
    this.stacksMap.set(id, stack);
    return stack;
  }

  async updateStack(id: number, updates: Partial<InsertSupplementStack>): Promise<SupplementStack> {
    const stack = this.stacksMap.get(id);
    if (!stack) throw new Error("Stack not found");
    const updated = { ...stack, ...updates } as SupplementStack;
    this.stacksMap.set(id, updated);
    return updated;
  }

  async deleteStack(id: number): Promise<void> {
    this.stacksMap.delete(id);
    // Remove stack supplements and reminders
    Array.from(this.stackSupplementsMap.entries()).forEach(([key, ss]) => {
      if (ss.stackId === id) this.stackSupplementsMap.delete(key);
    });
    Array.from(this.remindersMap.entries()).forEach(([key, r]) => {
      if (r.stackId === id) this.remindersMap.delete(key);
    });
  }

  // Stack-Supplement relationships
  async getStackSupplements(stackId: number): Promise<StackSupplement[]> {
    return Array.from(this.stackSupplementsMap.values()).filter(ss => ss.stackId === stackId);
  }

  async addSupplementToStack(insert: InsertStackSupplement): Promise<StackSupplement> {
    // Check if already exists
    const existing = Array.from(this.stackSupplementsMap.values()).find(
      ss => ss.stackId === insert.stackId && ss.supplementId === insert.supplementId
    );
    if (existing) return existing;
    
    const id = this.stackSupplementIdCounter++;
    const entry: StackSupplement = { ...insert, id };
    this.stackSupplementsMap.set(id, entry);
    return entry;
  }

  async removeSupplementFromStack(stackId: number, supplementId: number): Promise<void> {
    const entries = Array.from(this.stackSupplementsMap.entries());
    for (let i = 0; i < entries.length; i++) {
      const [key, ss] = entries[i];
      if (ss.stackId === stackId && ss.supplementId === supplementId) {
        this.stackSupplementsMap.delete(key);
        break;
      }
    }
  }

  // Reminders
  async getStackReminders(stackId: number): Promise<StackReminder[]> {
    return Array.from(this.remindersMap.values()).filter(r => r.stackId === stackId);
  }

  async getAllRemindersForUser(userId: number): Promise<StackReminder[]> {
    const userStacks = await this.getStacks(userId);
    const stackIds = new Set(userStacks.map(s => s.id));
    return Array.from(this.remindersMap.values()).filter(r => stackIds.has(r.stackId));
  }

  async getTodaysRemindersForUser(userId: number): Promise<Array<StackReminder & { stackName: string }>> {
    const userStacks = await this.getStacks(userId);
    const stackMap = new Map(userStacks.map(s => [s.id, s.name]));
    const reminders = Array.from(this.remindersMap.values()).filter(
      r => r.enabled && stackMap.has(r.stackId)
    );
    return reminders.map(r => ({
      ...r,
      stackName: stackMap.get(r.stackId) || "Unknown Stack",
      daysOfWeek: r.daysOfWeek
    }));
  }

  async createReminder(insert: InsertStackReminder): Promise<StackReminder> {
    const id = this.reminderIdCounter++;
    const reminder: StackReminder = { 
      ...insert, 
      id,
      enabled: insert.enabled ?? true
    };
    this.remindersMap.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: number, updates: Partial<InsertStackReminder>): Promise<StackReminder> {
    const reminder = this.remindersMap.get(id);
    if (!reminder) throw new Error("Reminder not found");
    const updated = { ...reminder, ...updates } as StackReminder;
    this.remindersMap.set(id, updated);
    return updated;
  }

  async deleteReminder(id: number): Promise<void> {
    this.remindersMap.delete(id);
  }

  // Supplement Logs
  async getSupplementLogs(userId: number, date: string): Promise<SupplementLog[]> {
    return Array.from(this.supplementLogsMap.values()).filter(
      l => l.userId === userId && l.date === date
    );
  }

  async createSupplementLog(insert: InsertSupplementLog): Promise<SupplementLog> {
    const id = this.supplementLogIdCounter++;
    const log: SupplementLog = { 
      ...insert, 
      id,
      stackId: insert.stackId ?? null,
      time: insert.time ?? null,
      taken: insert.taken ?? true
    };
    this.supplementLogsMap.set(id, log);
    return log;
  }

  async deleteSupplementLog(id: number): Promise<void> {
    this.supplementLogsMap.delete(id);
  }

  // Disclaimer acceptance
  async getDisclaimerAcceptance(userId: number, type: string): Promise<UserDisclaimerAcceptance | undefined> {
    return Array.from(this.disclaimerAcceptancesMap.values()).find(
      a => a.userId === userId && a.disclaimerType === type
    );
  }

  async createDisclaimerAcceptance(insert: InsertUserDisclaimerAcceptance): Promise<UserDisclaimerAcceptance> {
    const id = this.disclaimerIdCounter++;
    const acceptance: UserDisclaimerAcceptance = { ...insert, id };
    this.disclaimerAcceptancesMap.set(id, acceptance);
    return acceptance;
  }

  // Supplement Catalog
  async getSupplementCatalog(query?: string): Promise<SupplementCatalogItem[]> {
    const items = Array.from(this.supplementCatalogMap.values());
    if (!query || query.trim() === "") return items;
    const q = query.toLowerCase();
    return items.filter(item => item.name.toLowerCase().includes(q));
  }

  async getSupplementCatalogItem(id: number): Promise<SupplementCatalogItem | undefined> {
    return this.supplementCatalogMap.get(id);
  }

  // Supplement Intakes
  async getSupplementIntakes(userId: number, date: string): Promise<SupplementIntake[]> {
    return Array.from(this.supplementIntakesMap.values()).filter(
      i => i.userId === userId && i.date === date
    );
  }

  async getSupplementIntakesRange(userId: number, startDate: string, endDate: string): Promise<SupplementIntake[]> {
    return Array.from(this.supplementIntakesMap.values()).filter(
      i => i.userId === userId && i.date >= startDate && i.date <= endDate
    );
  }

  async createSupplementIntake(insert: InsertSupplementIntake): Promise<SupplementIntake> {
    const id = this.supplementIntakeIdCounter++;
    const intake: SupplementIntake = {
      ...insert,
      id,
      stackId: insert.stackId ?? null,
      reminderId: insert.reminderId ?? null,
      taken: insert.taken ?? true,
      takenAt: insert.takenAt ?? null
    };
    this.supplementIntakesMap.set(id, intake);
    return intake;
  }

  async updateSupplementIntake(id: number, updates: Partial<InsertSupplementIntake>): Promise<SupplementIntake> {
    const intake = this.supplementIntakesMap.get(id);
    if (!intake) throw new Error("Supplement intake not found");
    const updated = { ...intake, ...updates } as SupplementIntake;
    this.supplementIntakesMap.set(id, updated);
    return updated;
  }

  async deleteSupplementIntake(id: number): Promise<void> {
    this.supplementIntakesMap.delete(id);
  }
}

export const storage = new MemStorage();
