import { z } from 'zod';
import { insertUserSchema, insertLogSchema, insertFoodEntrySchema, users, logs, foodEntries, onboardingSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  user: {
    get: {
      method: 'GET' as const,
      path: '/api/user/:username',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: { // Simple signup/login
      method: 'POST' as const,
      path: '/api/user',
      input: z.object({ username: z.string() }),
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
      },
    },
    onboard: {
        method: 'POST' as const,
        path: '/api/user/:username/onboard',
        input: onboardingSchema,
        responses: {
            200: z.custom<typeof users.$inferSelect>(),
        }
    }
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs/:username',
      responses: {
        200: z.array(z.custom<typeof logs.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/logs',
      input: insertLogSchema,
      responses: {
        201: z.custom<typeof logs.$inferSelect>(),
      },
    },
    update: { 
        method: 'PATCH' as const,
        path: '/api/logs/:id',
        input: insertLogSchema.partial(),
        responses: {
            200: z.custom<typeof logs.$inferSelect>(),
            404: errorSchemas.notFound,
        }
    }
  },
  food: {
    list: {
      method: 'GET' as const,
      path: '/api/food/:username/:date',
      responses: {
        200: z.array(z.custom<typeof foodEntries.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/food',
      input: insertFoodEntrySchema,
      responses: {
        201: z.custom<typeof foodEntries.$inferSelect>(),
      }
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/food/:id',
      responses: {
        204: z.null(),
        404: errorSchemas.notFound,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
