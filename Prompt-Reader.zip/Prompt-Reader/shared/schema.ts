import { pgTable, text, serial, integer, boolean, date, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  // Onboarding fields
  age: integer("age"),
  gender: text("gender"), // 'male', 'female'
  height: integer("height"), // cm
  currentWeight: real("current_weight"), // kg
  activityLevel: text("activity_level"), // 'sedentary', 'light', 'moderate', 'active', 'very_active'
  goal: text("goal"), // 'fat_loss'
  experienceLevel: text("experience_level"), // 'beginner', 'intermediate', 'advanced'
  // Calculated Targets
  targetCalories: integer("target_calories"),
  targetProtein: integer("target_protein"),
  targetCarbs: integer("target_carbs"),
  targetFat: integer("target_fat"),
});

export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  weight: real("weight"),
  calories: integer("calories").default(0),
  protein: integer("protein").default(0),
  carbs: integer("carbs").default(0),
  fat: integer("fat").default(0),
  fibre: integer("fibre").default(0),
});

export const mealEnum = ["breakfast", "lunch", "dinner", "snack"] as const;
export type MealType = typeof mealEnum[number];

export const foodEntries = pgTable("food_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  name: text("name").notNull(),
  grams: integer("grams").default(100),
  calories: integer("calories").notNull(),
  protein: integer("protein").notNull(),
  carbs: integer("carbs").notNull(),
  fat: integer("fat").notNull(),
  fibre: integer("fibre").default(0),
  meal: text("meal").notNull().default("lunch"), // breakfast, lunch, dinner, snack
  snackIndex: integer("snack_index"), // Only used when meal='snack', null otherwise
});

export const weights = pgTable("weights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: text("date").notNull(), // ISO date string YYYY-MM-DD
  weight: real("weight").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertLogSchema = createInsertSchema(logs).omit({ id: true });
export const insertFoodEntrySchema = createInsertSchema(foodEntries).omit({ id: true });
export const insertWeightSchema = createInsertSchema(weights).omit({ id: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type FoodEntry = typeof foodEntries.$inferSelect;
export type InsertFoodEntry = z.infer<typeof insertFoodEntrySchema>;
export type Weight = typeof weights.$inferSelect;
export type InsertWeight = z.infer<typeof insertWeightSchema>;

// Onboarding input schema
export const onboardingSchema = insertUserSchema.pick({
  age: true,
  gender: true,
  height: true,
  currentWeight: true,
  activityLevel: true,
  experienceLevel: true,
  goal: true,
});

export type OnboardingData = z.infer<typeof onboardingSchema>;

// Supplement Catalog (predefined supplements with micronutrient data)
export const supplementCatalog = pgTable("supplement_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  defaultUnit: text("default_unit").notNull(), // mg, mcg, IU, g
  microsPerUnit: text("micros_per_unit").notNull(), // JSON object mapping nutrient keys to amounts
  notes: text("notes"),
});

// Supplement Tracker Tables
export const supplements = pgTable("supplements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  brand: text("brand"),
  form: text("form"), // pill, capsule, powder, liquid, etc.
  notes: text("notes"),
  catalogId: integer("catalog_id"), // FK to supplement_catalog, null for custom
  doseAmount: real("dose_amount"), // e.g. 25
  doseUnit: text("dose_unit"), // e.g. mcg, mg, IU
});

// Daily supplement intake tracking (per slot: stackId + reminderId + supplementId + date)
export const supplementIntakes = pgTable("supplement_intakes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
  stackId: integer("stack_id"), // null for standalone supplements
  reminderId: integer("reminder_id"), // null for standalone supplements
  date: text("date").notNull(), // YYYY-MM-DD
  taken: boolean("taken").notNull().default(true),
  takenAt: text("taken_at"), // ISO timestamp
});

export const supplementStacks = pgTable("supplement_stacks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
});

export const stackSupplements = pgTable("stack_supplements", {
  id: serial("id").primaryKey(),
  stackId: integer("stack_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
});

export const daysOfWeekEnum = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;
export type DayOfWeek = typeof daysOfWeekEnum[number];

export const stackReminders = pgTable("stack_reminders", {
  id: serial("id").primaryKey(),
  stackId: integer("stack_id").notNull(),
  time: text("time").notNull(), // HH:MM format
  daysOfWeek: text("days_of_week").notNull(), // JSON array of days
  enabled: boolean("enabled").notNull().default(true),
});

export const supplementLogs = pgTable("supplement_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  supplementId: integer("supplement_id").notNull(),
  stackId: integer("stack_id"),
  date: text("date").notNull(), // YYYY-MM-DD
  time: text("time"), // HH:MM
  taken: boolean("taken").notNull().default(true),
});

export const userDisclaimerAcceptance = pgTable("user_disclaimer_acceptance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  disclaimerType: text("disclaimer_type").notNull(), // 'supplement_reminders'
  acceptedAt: text("accepted_at").notNull(), // ISO timestamp
});

// Insert schemas
export const insertSupplementCatalogSchema = createInsertSchema(supplementCatalog).omit({ id: true });
export const insertSupplementSchema = createInsertSchema(supplements).omit({ id: true });
export const insertSupplementIntakeSchema = createInsertSchema(supplementIntakes).omit({ id: true });
export const insertSupplementStackSchema = createInsertSchema(supplementStacks).omit({ id: true });
export const insertStackSupplementSchema = createInsertSchema(stackSupplements).omit({ id: true });
export const insertStackReminderSchema = createInsertSchema(stackReminders).omit({ id: true });
export const insertSupplementLogSchema = createInsertSchema(supplementLogs).omit({ id: true });
export const insertUserDisclaimerAcceptanceSchema = createInsertSchema(userDisclaimerAcceptance).omit({ id: true });

// Types
export type SupplementCatalogItem = typeof supplementCatalog.$inferSelect;
export type InsertSupplementCatalogItem = z.infer<typeof insertSupplementCatalogSchema>;
export type Supplement = typeof supplements.$inferSelect;
export type InsertSupplement = z.infer<typeof insertSupplementSchema>;
export type SupplementIntake = typeof supplementIntakes.$inferSelect;
export type InsertSupplementIntake = z.infer<typeof insertSupplementIntakeSchema>;
export type SupplementStack = typeof supplementStacks.$inferSelect;
export type InsertSupplementStack = z.infer<typeof insertSupplementStackSchema>;
export type StackSupplement = typeof stackSupplements.$inferSelect;
export type InsertStackSupplement = z.infer<typeof insertStackSupplementSchema>;
export type StackReminder = typeof stackReminders.$inferSelect;
export type InsertStackReminder = z.infer<typeof insertStackReminderSchema>;
export type SupplementLog = typeof supplementLogs.$inferSelect;
export type InsertSupplementLog = z.infer<typeof insertSupplementLogSchema>;
export type UserDisclaimerAcceptance = typeof userDisclaimerAcceptance.$inferSelect;
export type InsertUserDisclaimerAcceptance = z.infer<typeof insertUserDisclaimerAcceptanceSchema>;
