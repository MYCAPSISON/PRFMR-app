export interface Ingredient {
  name: string;
  calories_per_100g: number;
  protein_g_per_100g: number;
  carbs_g_per_100g: number;
  fat_g_per_100g: number;
  fibre_g_per_100g: number;
  // Optional micronutrients
  iron_mg_per_100g?: number | null;
  calcium_mg_per_100g?: number | null;
  magnesium_mg_per_100g?: number | null;
  zinc_mg_per_100g?: number | null;
  potassium_mg_per_100g?: number | null;
  vitamin_c_mg_per_100g?: number | null;
  vitamin_a_ug_per_100g?: number | null;
  vitamin_b12_ug_per_100g?: number | null;
  folate_ug_per_100g?: number | null;
  iodine_ug_per_100g?: number | null;
  selenium_ug_per_100g?: number | null;
  vitamin_d_ug_per_100g?: number | null;
}

export function getMicronutrientValue(ingredient: Ingredient | any, key: string): number | null {
  const value = (ingredient as any)[key];
  return (value === undefined || value === null) ? null : Number(value);
}
